package com.priti.basic.presentation;

import java.util.Scanner;

import com.priti.basic.dao.EmployeeDao;
import com.priti.basic.dao.EmployeeDaoImpl;
import com.priti.basic.entity.Employee;

public class AppImpl implements App
{
    Scanner scanner=new Scanner(System.in);
	public void addRecord()
	{
		System.out.println("Enter The Number");
		Integer empNum=scanner.nextInt();
		
		System.out.println("Enter The Name");
		String empName=scanner.next();
		
		System.out.println("Enter The Salary");
		Float empSal=scanner.nextFloat();
		
		Employee employee=new Employee();
		employee.setEmpNum(empNum);
		employee.setEmpName(empName);
		employee.setEmpSal(empSal);
	    
		EmployeeDao employeeDao=new EmployeeDaoImpl();
		String res=employeeDao.addRecord(employee);
		System.out.println(res);
		
	}
	
	public void updateRecord() 
	{
			System.out.println("Enter The Number");
			Integer empNum=scanner.nextInt();
			
			System.out.println("Enter The Name");
			String empName=scanner.next();
			
			System.out.println("Enter The Salary");
			Float empSal=scanner.nextFloat();
			
			Employee employee=new Employee();
			employee.setEmpNum(empNum);
			employee.setEmpName(empName);
			employee.setEmpSal(empSal);
		    
			EmployeeDao employeeDao=new EmployeeDaoImpl();
			String res=employeeDao.updateRecord(employee);
			System.out.println(res);
		
	}

	@Override
	public void deleteRecord() 
	{
		System.out.println("Enter The Number");
		Integer empNum=scanner.nextInt();
		EmployeeDao employeeDao=new EmployeeDaoImpl();
		System.out.println(employeeDao.deleteRecord(empNum));
	}

	@Override
	public void showRecord() 
	{
		System.out.println("Enter The Number");
		Integer empNum=scanner.nextInt();
		
		EmployeeDao employeeDao=new EmployeeDaoImpl();
		Employee employee=employeeDao.showRecord(empNum);
		if(employee!=null) 
		{
			System.out.println(employee.getEmpNum());
			System.out.println(employee.getEmpName());
			System.out.println(employee.getEmpSal());
		}
		else {
			System.out.println("Object not Found...");
		}
	      
	}
	
}
