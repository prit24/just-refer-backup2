package com.priti.basic.presentation;

import java.util.Scanner;

import com.priti.basic.entity.Employee;

public class TestApp
{
	public static void main(String[] args)
	{
		Integer ch=0;;
		Scanner scanner = new Scanner(System.in);
		App app = new AppImpl();
		
		while(true)
		{
			System.out.println("************* Menu **********");
			System.out.println("\t 1.Add Record" );
			System.out.println("\t 2.Modify Record");
			System.out.println("\t 3.Delete Record");
			System.out.println("\t 4.Search Record by Id");
				
			System.out.println("If you want to continue then enter your choice :");
			ch = scanner.nextInt();
			
			
						
			switch(ch)
			{
				case 1:
					app.addRecord();
					
					break;
				
				case 2:
					app.updateRecord();
					break;
				
				case 3:
					app.deleteRecord();
					break;
			
				case 4:
					app.showRecord();
					break;
			
				default :
					System.exit(0);
			
			}
		}
		
	}

}