package com.priti.basic.presentation;

public class EmployeeDaoImpl implements EmployeeDao 
{

	@Override
	public String addRecord(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

}
