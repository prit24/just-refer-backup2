package com.priti.basic.presentation;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee 
{@Id
     private Integer empNum;
     private String empName;
     private Float empSal;
	public Integer getEmpNum() {
		return empNum;
	}
	public void setEmpNum(Integer empNum) {
		this.empNum = empNum;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Float empSal) {
		this.empSal = empSal;
	}
     
}
