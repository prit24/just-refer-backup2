package com.priti.basic.presentation;

public interface EmployeeDao 
{

	String addRecord(Employee employee);
     
}
