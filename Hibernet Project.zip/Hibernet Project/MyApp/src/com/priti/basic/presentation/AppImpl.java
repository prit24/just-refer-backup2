package com.priti.basic.presentation;

import java.util.Scanner;


public class AppImpl implements App
{
	Scanner scanner=new Scanner(System.in);
	public void addRecord() 
	{
		System.out.println("Enter The Number");
		Integer empNum=scanner.nextInt();
		
		System.out.println("Enter The Name");
		String empName=scanner.next();
		
		System.out.println("Enter The salary");
		Float empSal=scanner.nextFloat();
		
		Employee employee= new Employee();
		
		employee.setEmpNum(empNum);
		employee.setEmpName(empName);
		employee.setEmpSal(empSal);
		
		EmployeeDao employeeDao=new EmployeeDaoImpl();
		String res=employeeDao.addRecord(employee);
		System.out.println(res);
	}

}
