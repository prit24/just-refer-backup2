package com.priti.basic.presentation;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
public class MyApp1 {

	public static void main(String[] args) 
	{	
			Integer choice;
			
			 Scanner scanner = new Scanner(System.in);
			 
										
				while(true) {

					System.out.println("Employee Management System");
					System.out.println("1.Enter new Record");
					System.out.println("2.Update Record");
					System.out.println("3.Delete Record");
					System.out.println("4.Display Record");
					System.out.println("5.Exit");
					System.out.println("Enter your choice:: ");
					choice   = scanner.nextInt();
						
					switch(choice)
					{
						case 1:
							break;
						

						default :
							System.exit(0);
					}
				}
	}
}

 

      
   


