package myPack;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp1 
{
      public static void main(String[] args)
      {
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter The Employee Number");
		Integer eNum=scanner.nextInt();
		
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("raj");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Employee employee=entityManager.find(Employee.class, eNum);
		
		if(employee!=null)
		{
			entityManager.remove(employee);
			System.out.println("Removed Employee");
		}
		
	}
}
