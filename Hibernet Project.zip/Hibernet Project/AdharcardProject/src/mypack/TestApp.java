package mypack;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
//insert
public class TestApp {

	public static void main(String[] args) {
		
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		 
	  	Person person=new Person();
	  	person.setpName("priti");
	  	person.setpEmail("priti@2223gmail.com");
	  	
	  	AdharCard adharCard=new AdharCard();	
	  	adharCard.setAadharNo(1000991);
	  	adharCard.setAadharPinCode(434207);
	  	entityTransaction.begin();
	 	person.setAadhar(adharCard);
	 	 entityManager.persist(adharCard);;
		
		entityTransaction.commit();
		
		entityManager.close();
		entityManagerFactory.close();
		System.out.println("Save Object....");
	
	}

}