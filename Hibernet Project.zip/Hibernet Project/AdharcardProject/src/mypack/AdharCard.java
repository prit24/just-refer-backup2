package mypack;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AdharCard {
	@Id
	private Integer aadharNo;
	public Integer agetAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(Integer aadharNo) {
		this.aadharNo = aadharNo;
	}
	public Integer getAadharPinCode() {
		return aadharPinCode;
	}
	public void setAadharPinCode(Integer aadharPinCode) {
		this.aadharPinCode = aadharPinCode;
	}
	private Integer aadharPinCode;
	

}