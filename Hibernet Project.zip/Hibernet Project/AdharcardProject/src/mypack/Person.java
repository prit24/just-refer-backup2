package mypack;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Person {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String pName;
	private String  pEmail;
	@OneToOne(cascade =CascadeType.ALL)
	@JoinColumn(name="aadharNo")
	private AdharCard aadhar;
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpEmail() {
		return pEmail;
	}
	public void setpEmail(String pEmail) {
		this.pEmail = pEmail;
	}
	public AdharCard getAadhar() {
		return aadhar;
	}
	public void setAadhar(AdharCard aadhar) {
		this.aadhar = aadhar;
	}
	
	
	
	

}