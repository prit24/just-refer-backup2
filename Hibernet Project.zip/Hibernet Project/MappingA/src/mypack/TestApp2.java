package mypack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestApp2 
{

	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		Integer pNo=2;
		Person person=entityManager.find(Person.class, pNo);
		
		Address1 address1=person.getAddress1();
		
		System.out.println("House No is :"+address1.getHouseNo());
		System.out.println("House Name is :"+address1.getHouseName());
		System.out.println("pincode is :"+address1.getPincode());
		entityManager.close();
		entityManagerFactory.close();
	}

}