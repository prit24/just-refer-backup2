package mypack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp3
{

	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		Integer pNo=1;
		Person person=entityManager.find(Person.class, pNo);
		
		if(person!=null) 
		{
			EntityTransaction entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			
			entityManager.remove(person);
			entityTransaction.commit();
			System.out.println("Employee removed");
				
		}
		else
		{
			System.out.println("Employee not found");
		}
		entityManager.close();
		entityManagerFactory.close();

}
}