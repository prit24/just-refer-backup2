package mypack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertRecord
{

	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Person person=new Person();
		
		person.setpName("ishu");
		person.setpEmail("ishu@gmail.com");
		
		Address1 address1=new Address1();
		address1.setHouseNo(365);
		address1.setHouseName("ishu Vila");
		address1.setPincode(874568);
		person.setAddress1(address1);
		
		entityTransaction.begin();
		entityManager.persist(person);
		entityTransaction.commit();
		entityManager.close();
		entityManagerFactory.close();
		
		System.out.println("Save Object");
	}

}
