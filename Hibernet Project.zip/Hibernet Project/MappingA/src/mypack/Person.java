package mypack;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Person 
{
	     @Id
	     @GeneratedValue(strategy = GenerationType.IDENTITY)
         
	     private Integer pNo;
         private String pName;
         public Integer getpNo() {
			return pNo;
		}
		public void setpNo(Integer pNo) {
			this.pNo = pNo;
		}
		public String getpName() {
			return pName;
		}
		public void setpName(String pName) {
			this.pName = pName;
		}
		public String getpEmail() {
			return pEmail;
		}
		public void setpEmail(String pEmail) {
			this.pEmail = pEmail;
		}
		public Address1 getAddress1() {
			return address1;
		}
		public void setAddress1(Address1 address1) {
			this.address1 = address1;
		}
		private String pEmail;
         @OneToOne(cascade = CascadeType.ALL)
         @JoinColumn(name="houseNo")
         private Address1 address1;
         
}
