package mypack;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestApp4
{
     public static void main(String[] args) 
     {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
        Scanner scanner=new Scanner(System.in);
		System.out.println("Enter The Name");
		String empName=scanner.next();
		
		String jpql="from Person p";
		Query q=entityManager.createQuery(jpql);
		List<Person>l=q.getResultList();
		Iterator<Person> itr=l.iterator();
		while(itr.hasNext())
		{
			Person person=itr.next();
			
			System.out.println(person.getAddress1().getHouseNo());
			System.out.println(person.getAddress1().getHouseName());
			System.out.println(person.getAddress1().getPincode());
			entityManager.close();
			entityManagerFactory.close();
		}		
	 } 
}
