package mypack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp1
{

	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		
		Person person =new Person();	
		person.setpName("radhika");
		person.setpEmail("radhika@gmail.com");
		Address1 address1=new Address1();
		
		address1.setHouseNo(798);
		address1.setHouseName("Navnand vila");
		address1.setPincode(41315);
		
		person.setAddress1(address1);
		entityTransaction.begin();
		entityManager.persist(person);
		entityTransaction.commit();
		entityManager.close();
		entityManagerFactory.close();
		System.out.println("object saved");
		
	}

}
