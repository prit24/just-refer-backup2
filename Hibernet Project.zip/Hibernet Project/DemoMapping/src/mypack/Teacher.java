package mypack;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Teacher 
{    
	 @Id
     private Integer tId;
     public Integer gettId() {
		return tId;
	}
	public void settId(Integer tId) {
		this.tId = tId;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public String gettSub() {
		return tSub;
	}
	public void settSub(String tSub) {
		this.tSub = tSub;
	}
	private String tName;
     private String tSub;
  
}
