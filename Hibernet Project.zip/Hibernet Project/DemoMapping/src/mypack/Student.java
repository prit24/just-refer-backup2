package mypack;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student 
{
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
      private Integer sNo;
      public Integer getsNo() {
		return sNo;
	}

	public void setsNo(Integer sNo) {
		this.sNo = sNo;
	}

	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	public String getsDep() {
		return sDep;
	}

	public void setsDep(String sDep) {
		this.sDep = sDep;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	private String sName;
      private String sDep;
      
      private Teacher teacher;
      
}
