package com.project.library.service;

import com.project.library.entity.Student;

public class StudentServiceImpl implements StudentService{
	StudentService studentService=new StudentServiceImpl();

	@Override
	public String addStudent(Student student) {
		// TODO Auto-generated method stub
		return studentService.addStudent(student);
	}

	@Override
	public String getStudentById(Integer studentId) {
		// TODO Auto-generated method stub
		return studentService.getStudentById(studentId);
	}
	
	
	

}