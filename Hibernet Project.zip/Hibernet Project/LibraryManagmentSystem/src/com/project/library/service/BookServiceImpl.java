package com.project.library.service;

import java.util.List;

import com.project.library.dao.BookDao;
import com.project.library.dao.BookDaoImpl;
import com.project.library.entity.Book;



public class BookServiceImpl implements BookService {
	
	BookDao bookDao = new BookDaoImpl();

	public String registeredBook(Book book) {
		
        return bookDao.registeredBook(book);
		
	}

	public List<Book> getAllBooks() {
		
		return bookDao.getAllBooks();
	}

	public Book getBookById(Integer bookId) {
		
		return bookDao.getBookById(bookId);
	}

	public List<Book> getAllBookByName(String bookName) {
		
		return bookDao.getBookByName(bookName);
	}

	public List<Book> getAllBookByType(String bookType) {
		
		return bookDao.getBookByType(bookType);
	}

	public String updateStock(Book book) {
		
		return bookDao.updateStock(book);
	}



}