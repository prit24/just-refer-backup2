package com.project.library.service;

import java.util.List;

import com.project.library.entity.Book;



public interface BookService {
	String registeredBook(Book book);
    List<Book> getAllBooks();
    Book getBookById(Integer bookId);
    List<Book> getAllBookByName(String bookName);
    List<Book> getAllBookByType(String bookType);
    public  String updateStock(Book book);

   
}