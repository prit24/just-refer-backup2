package com.project.library.service;

import com.project.library.dao.BookIssueDao;
import com.project.library.dao.BookIssueDaoImpl;
import com.project.library.entity.BookIssue;

public class BookIssueServiceImpl implements BookIssueService{

	private BookIssueDao bookIssueDao=new BookIssueDaoImpl();
	
	@Override
	public String issueBook(BookIssue bookIssue) {
		
		return bookIssueDao.issueBook(bookIssue);
	}

	@Override
	public String returnBook(BookIssue bookIssue) {
		// TODO Auto-generated method stub
		return bookIssueDao.returnBook(bookIssue);
	}

}