package com.project.library.service;

import com.project.library.entity.Student;

public interface StudentService {
	String addStudent(Student student);
	String  getStudentById(Integer studentId);
}