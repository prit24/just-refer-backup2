package com.project.library.dao;

import com.project.library.entity.BookIssue;

public interface BookIssueDao 
{

	public String issueBook(BookIssue bookIssue);
	public String returnBook(BookIssue bookIssue);
}