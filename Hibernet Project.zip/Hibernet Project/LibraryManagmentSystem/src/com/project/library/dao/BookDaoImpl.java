package com.project.library.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.project.library.entity.Book;



public class BookDaoImpl implements BookDao{
	
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("raj");
	EntityManager entityManager=MyConnection.getEntityManagerObject();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	Query query;
	
	public String registeredBook(Book book) 
	{
		entityTransaction.begin();
		entityManager.persist(book);
		entityTransaction.commit();
		return "Book Registered";
	}


	public List<Book> getAllBooks() {
		String jpql="select b from Book b";
		query=entityManager.createQuery(jpql);
		List<Book> list=query.getResultList();
		return list;
	}

	public Book getBookById(Integer bookId) {
		Book book=entityManager.find(Book.class, bookId);
		return book;
	}

	public List<Book> getBookByName(String bookName) {
		
		String jpql="select b from Book b where b.bookName like "+bookName+"%";
		query=entityManager.createQuery(jpql);
		List<Book> list=query.getResultList();
		return list;
	}

	public List<Book> getBookByType(String bookType) {
		String jpql="select b from Book b where b.bookType=?1";
		query=entityManager.createQuery(jpql);
		query.setParameter(1, bookType);
		List<Book> list=query.getResultList();
		return list;
	}


	public String updateStock(Book book) {
		entityTransaction.begin();
		query=entityManager.createQuery("update Book b set b.quantity=?1 where b.bookId=?2");
		query.setParameter(1,book.getQuantity());
		query.setParameter(2,book.getQuantity());
		entityTransaction.commit();
		return "Stock Updated";
	}



}