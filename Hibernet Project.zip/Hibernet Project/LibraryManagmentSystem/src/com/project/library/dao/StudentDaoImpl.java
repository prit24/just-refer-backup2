package com.project.library.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.project.library.entity.Student;



public class StudentDaoImpl implements StudentDao
{
	EntityManager entityManager=MyConnection.getEntityManagerObject();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	
	public String registerStudent(Student student) 
	{
		entityTransaction.begin();
		entityManager.persist(student);
		entityTransaction.commit();
		
		return "Student Registration  done\nStudentId :"+student.getStudId();
	}

	public Student getStudentById(Integer studId) 
	{
		
		return entityManager.find(Student.class, studId);
	}

}