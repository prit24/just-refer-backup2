package com.project.library.dao;

import java.util.List;

import com.project.library.entity.Book;



public interface BookDao 
{
	String registeredBook(Book book);
    List<Book> getAllBooks();
    Book getBookById(Integer bookId);
    List<Book> getBookByName(String bookName);
    List<Book> getBookByType(String bookType);
    public  String updateStock(Book book);
	
}