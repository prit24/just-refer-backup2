package com.project.library.exception;

public class InvalidInputException {

}
