package com.project.library.presentation;

public class StudentUserImpl implements StudentUser {

}
