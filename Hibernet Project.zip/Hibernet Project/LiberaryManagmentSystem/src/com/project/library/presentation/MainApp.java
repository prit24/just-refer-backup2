package com.project.library.presentation;

import java.util.Scanner;


public class MainApp {

	public static void main(String[] args) {
		
		
		Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n------------Main Menu-----------");
            System.out.println("1. Admin");
            System.out.println("2. Student");
            System.out.println("3. Exit");

            System.out.print("\nEnter your choice: ");
            int Choice = scanner.nextInt();

            switch (Choice) {
                case 1:
                    Admin();
                    break;
                case 2:
                   Student();
                    break;
                case 3:
                    System.out.println("Exiting the program. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
	}

    private static void Admin() {
        Scanner scanner = new Scanner(System.in);
        while(true) {
        System.out.println("~~~~~~~~Welcome Page to admin~~~~~~~~~~");
        System.out.println("1.Registered Book ");
        System.out.println("2. Update Book");
        System.out.println("3. display Book");
        /*
        System.out.println("3. Confirm Book Issue");
        System.out.println("4. Display Unreturned Books");
        System.out.println("5. Display Unissued Books ");
        System.out.println("6. Display Fine details");
        */
        System.out.println("4. Logout");




        System.out.print("\nEnter your choice for Admin: ");
        int subChoice = scanner.nextInt();
        BookUser bookUser= new BookUserImpl();
        switch (subChoice) {
        case 1:
        	System.out.println("Register Book");
            bookUser.inputRegisteredBook();
            break;
        case 2:
        	System.out.println("Upadte Book");
            bookUser.inputUpdateStock();
            break;
        case 3:
        	System.out.println("display Book ");
         
            break;
            
        case 4:
        	System.out.println("Display Unreturned Books");
          
             break;
             
        case 5:
        	System.out.println("Display Unissued Books");
         
             break;
        case 6:
        	System.out.println("Display Fine details");
       
             break;
        case 7:
        	 //System.out.println("Exiting the program. Goodbye!");
        	 System.out.println("\nLogging out from Admin. Returning to Main Menu.");
             return;
         default:
             System.out.println("Invalid choice. Please enter a valid option.");
        }
    }
    }
    private static void Student() {
        Scanner scanner = new Scanner(System.in);
        while(true) {
        System.out.println("\n~~~~~~~~~~~~~Welcome Page to Student~~~~~~~~~~~~~~~~\n");
        System.out.println("1. Register book");
        System.out.println("2. Search Book");
        System.out.println("3. Return book");
        System.out.println("4. pay fine");
        System.out.println("5. Issue Book");
        System.out.println("6. View fine details");
        System.out.println("7. View profile");
        System.out.println("8. Show all books");
        System.out.println("9. View Borrowed Details");
        System.out.println("10. Logout");

        System.out.print("\nEnter your choice for Student: ");
        int subChoice = scanner.nextInt();
        BookUser bookUser= new BookUserImpl();
       
        switch (subChoice) {
        case 1:
        	 System.out.println("Register book");
          
            break;
        case 2:
        	
        	System.out.println(" Search Book");
           
            break;
        case 3:
        	System.out.println("Return book");
      
            break;
            
        case 4:
        	System.out.println("5. Issue Book");
         
             break;
             
        case 5:
        	 System.out.println("pay fine");
            
             break;
        case 6:
        	System.out.println("view fine details");
             
        	break;
        case 7:
        	System.out.println("view profile");
           
             break;
        case 8:
        	  System.out.println("show all books");
            
             break;
        case 9:
        	System.out.println("View Borrowed Details");
            
             break;
        case 10:
        	System.out.println("\nLogging out from Admin. Returning to Main Menu.");
            return;
         default:
             System.out.println("Invalid choice. Please enter a valid option.");
        }
        }
    
		
	}
    
}