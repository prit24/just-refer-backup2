package com.project.library.presentation;

public class BookIssueUserImpl implements BookIssueUser {

}
