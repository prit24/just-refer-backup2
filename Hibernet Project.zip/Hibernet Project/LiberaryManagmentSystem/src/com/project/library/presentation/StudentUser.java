package com.project.library.presentation;

public interface StudentUser {

}
