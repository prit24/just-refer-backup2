package com.project.library.presentation;

public interface Library 
{
     void student();
     void book();
     void Exit();
}
