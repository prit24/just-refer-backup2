package com.project.library.presentation;

public interface BookUser {
	void inputRegisteredBook();
    void inputGetAllBooks();
   void inputGetBookById();
    void inputGetBookByName();
    void inputGetBookByType();
    void inputUpdateStock();
}