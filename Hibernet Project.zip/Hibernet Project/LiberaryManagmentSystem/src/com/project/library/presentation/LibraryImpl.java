package com.project.library.presentation;

import java.util.Scanner;

public class LibraryImpl implements Library
{

	@Override
	public void student() 
	{
		System.out.println("---------------------------------");
		System.out.println("Welcome To Student Page");
		System.out.println("---------------------------------");
		System.out.println(" ");
		System.out.println("Registered Student");
		System.out.println("Search Book");
		System.out.println("Issue Book");
		System.out.println("Return Book");
		System.out.println("Show All Fine");
		System.out.println("Pay Fine");
		System.out.println("View Profile");
		System.out.println("View All books");
		System.out.println("Show Borrowed Book");
		System.out.println("LoggOut");
		
	}

	@Override
	public void book() 
	{
		System.out.println("---------------------------------");
		System.out.println("Welcome To Book Page");
		System.out.println("---------------------------------");
		System.out.println(" ");
		System.out.println("Add Book");
		System.out.println("Update Book Stock");
		System.out.println("Cofirm Book Issue");
		System.out.println("Display Unreturned Book");
		System.out.println("Display Fine Detail");
		System.out.println("LoggOut");	
		
	}

	@Override
	public void Exit() 
	{
		System.out.println("Exit Screen");
	}
}
