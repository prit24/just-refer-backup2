package com.project.library.presentation;

import java.util.Scanner;

import com.project.library.entity.Book;
import com.projectlibrary.service.BookService;
import com.projectlibrary.service.BookServiceImpl;

import antlr.collections.List;

public class BookUserImpl implements BookUser{
	private Scanner sc = new Scanner(System.in);
	@Override
	public void inputRegisteredBook() {
		System.out.println("Enter Book Name:");
		String bookName=sc.next();
		System.out.println("Enter Book Author Name:");
		String author=sc.next();
		System.out.println("Enter Book Quantity:");
		int bookQuantity=sc.nextInt();
		System.out.println("Enter Book Type:");
		String bookType=sc.next();
		Book book =new Book();
		book.setBookName(bookName);
		book.setAuthorName(author);
		book.setBookType(bookType);
		book.setQuantity(bookQuantity);
		book.setBookIssue(null);
		
		BookService bookService =new BookServiceImpl();
		System.out.println(bookService.registeredBook(book));
	}

	@Override
	public void inputGetAllBooks() {
		
		
	}

	@Override
	public void inputGetBookById() {
		System.out.println("Enter Book ID:");
	    int bookId = sc.nextInt();

	    // Call the BookService method to get the book by ID
	    BookService bookService = new BookServiceImpl();  // Consider injecting this dependency
	    Book book = bookService.getBookById(bookId);

	    // Display the book details
	    if (book != null) {
	        System.out.println("Book Details:");
	        System.out.println("Book ID: " + book.getBookId());
	        System.out.println("Book Name: " + book.getBookName());
	        System.out.println("Author: " + book.getAuthorName());
	        System.out.println("Quantity: " + book.getQuantity());
	        System.out.println("Type: " + book.getBookType());
	        // Add more details as needed

	    } else {
	        System.out.println("Book not found with ID: " + bookId);
	    }
		
	}

	@Override
	public void inputGetBookByName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void inputGetBookByType() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void inputUpdateStock() {
		System.out.println("Enter Book ID:");
	    int bookId = sc.nextInt();
	    System.out.println("Enter Quantity to Add:");
	    int quantityToAdd = sc.nextInt();

	    // Call the BookService method to get the book by ID
	    BookService bookService = new BookServiceImpl();  // Consider injecting this dependency
	    Book book = bookService.getBookById(bookId);

	    // Update the quantity
	    if (book != null) {
	        book.setQuantity(book.getQuantity() + quantityToAdd);

	        // Call the BookService method to update the stock
	        String updateResult = bookService.updateStock(book);

	        System.out.println(updateResult);
	    } else {
	        System.out.println("Book not found with ID: " + bookId);
	    }
		
	}

}