package com.project.library.dao;

import com.project.library.entity.Student;

public interface StudentDao {

		String registerStudent(Student student);
		Student getStudentById(Integer studId);
}