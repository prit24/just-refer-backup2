package com.project.library.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.project.library.entity.BookIssue;



public class BookIssueDaoImpl implements BookIssueDao {
	EntityManager entityManager=MyConnection.getEntityManagerObject();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	@Override
	public String issueBook(BookIssue bookIssue) {
		entityTransaction.begin();
		entityManager.persist(bookIssue);
		entityTransaction.commit();
		return "Book issue request sended to the Admin";
	}
	
	@Override
	public String returnBook(BookIssue bookIssue) {
		BookIssue bookIssue1=entityManager.find(BookIssue.class, bookIssue.getIssueId());
		if(bookIssue1!=null) {
			entityTransaction.begin();
			bookIssue1.setReturnDate(bookIssue.getReturnDate());
			bookIssue1.setBookStatus(bookIssue.getBookStatus());
			entityTransaction.commit();
		}
		return "Book returned";
	}
	
}