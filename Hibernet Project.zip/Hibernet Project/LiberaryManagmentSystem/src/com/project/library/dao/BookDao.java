package com.project.library.dao;

import java.util.List;

import com.project.library.entity.Book;



public interface BookDao {
	String registeredBook(Book book);
    List<Book> getAllBooks();
    Book getBookById(Integer bookId);
    List<Book> getBookByName(String bookName);
    List<Book> getBookByType(String bookType);
    public  String updateStock(Book book);
    
    
    /*
    String confirmBookIssue(int bookId, int studentId);
    
    List<Book> displayUnreturnedBooks();
    List<Book> displayUnissuedBooks();
    List<Book> displayFinedetails();
    String registeredStudent(Student student);
    Book searchBook(String title);
    String returnBook(int bookId, int studentId);
    String issueBook(int bookId, int studentId);
    String payFine(int studentId);
    List<Student> viewFineDetails();
    Student viewProfile(int studentId);
    List<Book> showAllBooks();
    List<Book> viewBorroweddetails(int studentId);
    */
}