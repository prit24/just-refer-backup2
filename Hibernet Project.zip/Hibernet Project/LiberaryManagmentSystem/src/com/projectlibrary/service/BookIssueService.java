package com.projectlibrary.service;

import com.project.library.entity.BookIssue;

public interface BookIssueService {
	public String issueBook(BookIssue bookIssue);
	public String returnBook(BookIssue bookIssue);
}