package com.priti.basic.dao;

import com.priti.basic.entity.Employee;

public interface EmployeeDao 
{
	String addRecord(Employee employee);

}
