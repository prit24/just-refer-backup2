package com.priti.basic.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.priti.basic.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao
{
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("raj");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	@Override
	public String addRecord(Employee employee) 
	{
		entityTransaction.begin();
		entityManager.persist(employee);
		entityTransaction.commit();
		return "addRecord";
	}

}
