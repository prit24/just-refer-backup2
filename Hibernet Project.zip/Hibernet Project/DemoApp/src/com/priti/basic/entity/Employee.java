package com.priti.basic.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Employee 
{      
	   @Id
     
	   private Integer StudentNum;
       private String StudentName;
       private Float StudentSal;
	
       public Integer getStudentNum() 
       {
		return StudentNum;
	   }
	   public void setStudentNum(Integer studentNum) 
	   {
		StudentNum = studentNum;
	   }
	   public String getStudentName() 
	   {
		return StudentName;
	   }
	   public void setStudentName(String studentName) 
	   {
		StudentName = studentName;
	    }
	   public Float getStudentSal() 
	   {
		return StudentSal;
	   }
	   public void setStudentSal(Float studentSal)
	   {
		StudentSal = studentSal;
	   }    
}
