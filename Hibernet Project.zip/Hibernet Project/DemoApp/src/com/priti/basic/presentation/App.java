package com.priti.basic.presentation;

public interface App 
{
     void addRecord();
    // void updateRecord();
     //void deleteRecord();
     //void showRecord();
}
