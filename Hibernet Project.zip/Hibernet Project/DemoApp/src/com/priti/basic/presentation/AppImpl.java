package com.priti.basic.presentation;

import java.util.Scanner;

import com.priti.basic.entity.Employee;
import com.priti.basic.service.EmployeeService;
import com.priti.basic.service.EmployeeServiceImpl;
public class AppImpl implements App
{
	Scanner scanner = new Scanner(System.in);
	EmployeeService employeeService = new EmployeeServiceImpl();
	@Override
	public void addRecord() 
	{
		
		System.out.println("Enter The Number");
		Integer StudentNum=scanner.nextInt();
		System.out.println("Enter The Name");
		String StudentName=scanner.next();
		System.out.println("Enter The Salary");
		Float StudentSal=scanner.nextFloat();
		
		Employee employee=new Employee();
		employee.setStudentNum(StudentNum);
		employee.setStudentName(StudentName);
		employee.setStudentSal(StudentSal);
		
		employeeService.addRecord(employee);
		}
}
	//@Override
	//public void updateRecord() 
//	{
		
	//}
	//@Override
	//public void deleteRecord() 
	//{
		
	//}
	//@Override
	//public void showRecord() 
	//{
		
	//}
//}
