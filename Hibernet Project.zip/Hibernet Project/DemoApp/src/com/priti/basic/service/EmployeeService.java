package com.priti.basic.service;

import com.priti.basic.entity.Employee;

public interface EmployeeService 
{
	String addRecord(Employee employee);
}
