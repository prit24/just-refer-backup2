package mypack;

import org.springframework.stereotype.Component;

@Component
public class Address
{

	private Integer houseNo;
	
	private String houseName;

	private Integer pinCode;

	@Override
	public String toString() {
		return "Address [houseNo=" + houseNo + ", houseName=" + houseName + ", pinCode=" + pinCode + "]";
	}

	public Address(Integer houseNo, String houseName, Integer pinCode) {
		super();
		this.houseNo = houseNo;
		this.houseName = houseName;
		this.pinCode = pinCode;
	}
	
	
	
	
	

}