package mypack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClient 
{
	public static void main(String[] args) 
	{
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("mypack/TestCfg.xml");
	
		TestBean tb = applicationContext.getBean(TestBean.class);
		System.out.println(tb);
		
		
		

	}

}