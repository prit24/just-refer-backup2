package mypack;

public class Address 
{
     private Integer houseNum;
     private String houseName;
     private Integer pincode;
     
     public String toString()
		{
			return "No is : " +houseNum+"\nName is : "+ houseName+"\npincode is : "+pincode;
		}
	public Integer getHouseNum()
	{
		return houseNum;
	}
	public void setHouseNum(Integer houseNum) 
	{
		this.houseNum = houseNum;
	}
	public String getHouseName() 
	{
		return houseName;
	}
	public void setHouseName(String houseName) 
	{
		this.houseName = houseName;
	}
	public Integer getPincode() 
	{
		return pincode;
	}
	public void setPincode(Integer pincode)
	{
		this.pincode = pincode;
	}
     
}
