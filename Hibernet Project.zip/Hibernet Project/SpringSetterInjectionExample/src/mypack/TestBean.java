package mypack;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TestBean 
{
 
    	 private int empNo;
    	 private String empName;
    	 private Float empSal;
         private Date empDoj;
         private Address empAddress;
         private List<String> empHobbies;
         private Set<String>projects;
         private Map<Integer,String>empTeamMember;
         private String client[];
         
	
		public String toString()
 		{
 			return "No is : " +empNo+"\nName is : "+ empName+"\nSal is : "+empSal+ "\nDoj is : "
 					+ ""+empDoj+"\n empAddress is : "+empAddress+"\nhoobies are : "+empHobbies+"\n Projects Name is : "
 		              +projects+"\n team members are : "+empTeamMember+"\n client Name is : "+client[0]+client[1];
 		}


		public int getEmpNo() {
			return empNo;
		}


		public void setEmpNo(int empNo) {
			this.empNo = empNo;
		}


		public String getEmpName() {
			return empName;
		}


		public void setEmpName(String empName) {
			this.empName = empName;
		}


		public Float getEmpSal() {
			return empSal;
		}


		public void setEmpSal(Float empSal) {
			this.empSal = empSal;
		}


		public Date getEmpDoj() {
			return empDoj;
		}


		public void setEmpDoj(Date empDoj) {
			this.empDoj = empDoj;
		}


		public Address getEmpAddress() {
			return empAddress;
		}


		public void setEmpAddress(Address empAddress) {
			this.empAddress = empAddress;
		}


		public List<String> getEmpHobbies() {
			return empHobbies;
		}


		public void setEmpHobbies(List<String> empHobbies) {
			this.empHobbies = empHobbies;
		}


		public Set<String> getProjects() {
			return projects;
		}


		public void setProjects(Set<String> projects) {
			this.projects = projects;
		}


		public Map<Integer, String> getEmpTeamMember() {
			return empTeamMember;
		}


		public void setEmpTeamMember(Map<Integer, String> empTeamMember) {
			this.empTeamMember = empTeamMember;
		}


		public String[] getClient() {
			return client;
		}


		public void setClient(String[] client) {
			this.client = client;
		} 
		
		
		
		
		
		
         
}