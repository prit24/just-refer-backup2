package mypack;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class TestClient 
{
	public static void main(String[] args) 
	{
		//  Resource resource=new FileSystemResource("TestCfg.xml");
         // BeanFactory beanFactory=new XmlBeanFactory(resource);
         // TestBean obj =(TestBean) beanFactory.getBean("tb");
         // obj.show();  
          
		// use above code if you are creating TestCfg.xml file in Project and use  below code
		//if your are you are creating TestCfg.xml file in src
		
          ApplicationContext applicationContext=new ClassPathXmlApplicationContext("TestCfg.xml");
          TestBean obj=applicationContext.getBean(TestBean.class);
          
          
          obj.toString();
          System.out.println(obj);	
	}
}
