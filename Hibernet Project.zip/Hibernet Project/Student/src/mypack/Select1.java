package mypack;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Select1
{
     public static void main(String[] args) 
     {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		String jpql="select e.empNo,e.empName,e.empSal from Employee e where e.empName=:Name";
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter The Name");
		String empName=scanner.next();
		
		Query q=entityManager.createQuery(jpql);
		q.setParameter("Name", empName);
		
		List<Object[]>l=q.getResultList();
		Iterator<Object[]> itr=l.iterator();
		while(itr.hasNext())
		{
			Object[] e=itr.next();
			System.out.println("Number"+e[0]);
			System.out.println("Name"+e[1]);
			System.out.println("Salary"+e[2]);
		}
	 } 
}
