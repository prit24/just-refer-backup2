package mypack;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertRecord {

	public static void main(String[] args) 
	{
		Scanner scanner=new Scanner(System.in);
		{
			System.out.println("Enter The Employee Number");
			Integer eNum=scanner.nextInt();
			
			System.out.println("Enter The Employee Name");
			String eName=scanner.next();
			
			System.out.println("Enter The Employee Salary");
			Float eSal=scanner.nextFloat();
			
			Employee employee=new Employee();
			
			employee.setEmpNo(eNum);
			employee.setEmpName(eName);
			employee.setEmpSal(eSal);
			
			EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
			EntityManager entityManager=entityManagerFactory.createEntityManager();
			EntityTransaction entityTransaction=entityManager.getTransaction();
			
			entityTransaction.begin();
			entityManager.persist(employee);
			entityTransaction.commit();
			entityManager.close();
			entityManagerFactory.close();
			
		}
		
       System.out.println("Save The Object");
	}

}