package mypack;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Select2
{
     public static void main(String[] args) 
     {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		String jpql="select e.empSal from Employee e where e.empName=:Name";
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter The Name");
		String empName=scanner.next();
		
		Query q=entityManager.createQuery(jpql);
		q.setParameter("Name", empName);
		
		List<Float>l=q.getResultList();
		Iterator<Float> itr=l.iterator();
		while(itr.hasNext())
		{
			Float empSal=itr.next();
			System.out.println("Employee Salary"+empSal);		
			}
	 } 
}