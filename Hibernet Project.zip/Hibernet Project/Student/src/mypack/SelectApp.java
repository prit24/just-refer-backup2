package mypack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import java.util.Iterator;
import java.util.List;

public class SelectApp 
{

	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		String jpql="select e from Employee e";
		
		Query q= entityManager.createQuery(jpql);
		
		List <Employee> l=q.getResultList();
		Iterator <Employee>itr=l.iterator();
		
		while(itr.hasNext())
		{
			Employee emp=itr.next();
			System.out.println("No is:"+emp.getEmpNo());
			System.out.println("Name is:"+emp.getEmpName());
			System.out.println("Salary is:"+emp.getEmpSal());
			
	}

	}
	}
