package mypack;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UpdateRecord
{
     public static void main(String[] args) 
     {
    	Scanner scanner=new Scanner(System.in);
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		String jpql="update Employee e set e.empName=:Name, e.empSal=:Sal where e.empNo=:No ";
		Query q=entityManager.createQuery(jpql);
		
		
		System.out.println("Enter The Number");
		Integer empNo=scanner.nextInt();
		
		System.out.println("Enter The Name");
		String empName=scanner.next();
		
		System.out.println("Enter The Salary");
		Float empSal=scanner.nextFloat();
		
		q.setParameter("No", empNo);
		q.setParameter("Name", empName);
		q.setParameter("Sal", empSal);
		
		entityTransaction.begin();
		int count=q.executeUpdate();
		entityTransaction.commit();
		
			System.out.println("Object updated sucessfully");		
			}
	 } 
