package mypack;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component

public class TestBean 
{
	@Value("101")
	private int empNo;
	@Value("radha")
	private String empName;
	@Value("900000")
	private Float empSal;
	
	@Autowired
	private Date empDoj;
	
	@Autowired
	private Address  empAddress;

	@Override
	public String toString() {
		return "TestBean [empNo=" + empNo + ", empName=" + empName + ", empSal=" + empSal + ", empDoj=" + empDoj
				+ ", empAddress=" + empAddress + "]";
	}
	
	
	
	
       
}