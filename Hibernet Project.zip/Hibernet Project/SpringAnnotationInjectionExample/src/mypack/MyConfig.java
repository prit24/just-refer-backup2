package mypack;

import java.sql.Date;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "mypack")

public class MyConfig 
{
	@Bean
	public Date getDateObject()
	{
		return new Date(0);
		
	}

	
	public Map<Integer, String> hobbies()
	{
		return Map.of(101, "reading", 102, "writing");
		
	}
}