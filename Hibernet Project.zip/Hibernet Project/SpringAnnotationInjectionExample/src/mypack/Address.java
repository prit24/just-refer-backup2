package mypack;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Address
{
	@Value("701")
	private Integer houseNo;
	@Value("Mexicon")
	private String houseName;
	@Value("413211")
	private Integer pinCode;
	
	
	@Override
	public String toString() {
		return "Address [houseNo=" + houseNo + ", houseName=" + houseName + ", pinCode=" + pinCode + "]";
	}
	
	
}