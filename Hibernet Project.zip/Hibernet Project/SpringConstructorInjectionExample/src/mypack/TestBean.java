package mypack;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import mypack.Address;
public class TestBean 
{

	private int empNo;
	
	private String empName;

	private Float empSal;
	
	private Address empAddress;

	private Date empDoj;
	
	private List<String> empHobbies;
	private Set<String> project;
	private Map<Integer, String> empTeamMember;
	private String client[];
	
	public String toString() {
		return "TestBean [empNo=" + empNo + ", empName=" + empName + ", empSal=" + empSal + ", empAddress=" + empAddress
				+ ", empDoj=" + empDoj + ", empHobbies=" + empHobbies + ", project=" + project + ", empTeamMember="
				+ empTeamMember + ", client=" + Arrays.toString(client) + "]";
	}
	public TestBean(int empNo, String empName, Float empSal, Address empAddress, Date empDoj, List<String> empHobbies,
			Set<String> project, Map<Integer, String> empTeamMember, String[] client) {
		super();
		this.empNo = empNo;
		this.empName = empName;
		this.empSal = empSal;
		this.empAddress = empAddress;
		this.empDoj = empDoj;
		this.empHobbies = empHobbies;
		this.project = project;
		this.empTeamMember = empTeamMember;
		this.client = client;
	}
	
	
	
		
	
}