package mypack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClient 
{
	public static void main(String[] args) 
	{
		//setter injection constructor ko override krtahai lekin 
		// constructor injection setter ko override nahi krta
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("mypack/TestCfg.xml");
		//TestBean tb = applicationContext.getBean(TestBean.class);
		//TestBean tb = (TestBean )applicationContext.getBean("tb");
		//TestBean tb = applicationContext.getBean(TestBean.class);
			
		//tb.toString();
		TestBean tb = applicationContext.getBean(TestBean.class);
		System.out.println(tb);
		
	}

}