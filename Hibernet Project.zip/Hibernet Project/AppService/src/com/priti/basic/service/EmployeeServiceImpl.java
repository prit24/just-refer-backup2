package com.priti.basic.service;

import com.priti.basic.dao.EmployeeDao;
import com.priti.basic.dao.EmployeeDaoImpl;
import com.priti.basic.entity.Employee;

public class EmployeeServiceImpl implements EmployeeService
{
	EmployeeDao employeeDao = new EmployeeDaoImpl();
	
	@Override
	public String addRecord(Employee employee) 
	{
		employeeDao.addRecord(employee);
		return "Add Record";
	}

	@Override
	public String updateRecord(Employee employee) 
	{
		employeeDao.updateRecord(employee);
		return "Update Record";
	}

	@Override
	public String deleteRecord(Integer emplNum) 
	{
		employeeDao.deleteRecord(emplNum);
		return "Delete Record";
	}

	@Override
	public Employee showRecord(Integer emplNum) 
	{
		employeeDao.showRecord(emplNum);
		Employee employee=null;
		return employee ;
	}
}
