package com.priti.basic.presentation;

import java.util.Scanner;

import com.priti.basic.dao.EmployeeDao;
import com.priti.basic.dao.EmployeeDaoImpl;
import com.priti.basic.entity.Employee;
import com.priti.basic.service.EmployeeService;
import com.priti.basic.service.EmployeeServiceImpl;

public class AppImpl implements App 
{
    
     Scanner scanner=new Scanner(System.in);
     
    @Override
	public void addRecord() 
	{
		System.out.println("Enter The Employee Number");
		Integer emplNum=scanner.nextInt();
		
		System.out.println("Enter The Employee Name");
		String emplName=scanner.next();
		
		System.out.println("Enter The Employee Salary");
		Float emplSal=scanner.nextFloat();
		
		 Employee employee=new Employee();
		employee.setEmplNum(emplNum);
		employee.setEmplName(emplName);
		employee.setEmplSal(emplSal);
		
		EmployeeService employeeService=new EmployeeServiceImpl();
		System.out.println(employeeService.addRecord(employee));
	}
    
    
    
    
    
    
	
    @Override
	public void updateRecord() 
	{
    	/*
    	System.out.println("Enter The Employee Number");
		Integer emplNum=scanner.nextInt();
		
		System.out.println("Enter The Employee Name");
		String emplName=scanner.next();
		
		System.out.println("Enter The Employee Salary");
		Float emplSal=scanner.nextFloat();
		
		 Employee employee=new Employee();
		employee.setEmplNum(emplNum);
		employee.setEmplName(emplName);
		employee.setEmplSal(emplSal);
		
		EmployeeService employeeService=new EmployeeServiceImpl();
		System.out.println(employeeService.updateRecord(employee)); */
	}
    @Override
	public void deleteRecord() 
    {
    	/*
    	 Employee employee=new Employee();
    	System.out.println("Enter The Employee Number");
		Integer emplNum=scanner.nextInt();
		employee.setEmplNum(emplNum);
		
		EmployeeService employeeService=new EmployeeServiceImpl();
		System.out.println(employeeService.deleteRecord(emplNum)); */
    }
    @Override
	public void showRecord() 
    {
    	/* Employee employee=new Employee();
    	System.out.println("Enter The Employee Number");
		Integer emplNum=scanner.nextInt();
		employee.setEmplNum(emplNum);
		
		EmployeeService employeeService=new EmployeeServiceImpl();
		System.out.println(employeeService.showRecord(emplNum));
		
		if(employee!=null) 
		{
			System.out.println(employee.getEmplNum());
			System.out.println(employee.getEmplName());
			System.out.println(employee.getEmplSal());
		}
		else {
			System.out.println("Object not Found...");  
		}*/
    }
}
