package com.priti.basic.dao;

import com.priti.basic.entity.Employee;

public interface EmployeeDao 
{
	String addRecord(Employee employee);
	String updateRecord(Employee employee);
	String deleteRecord(Integer emplNum );
	Employee showRecord(Integer emplNum);
}
