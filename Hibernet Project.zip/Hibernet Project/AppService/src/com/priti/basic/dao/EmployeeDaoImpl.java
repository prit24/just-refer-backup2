package com.priti.basic.dao;

import com.priti.basic.entity.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.priti.basic.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao
{
	Integer emplNum;
	@Override
	public String addRecord(Employee employee) 
	{    
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("raj");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
	
		
		
		entityTransaction.begin();
		entityManager.persist(employee);
		entityTransaction.commit();
		
		
		
		return "Add Record";
	}

	@Override
	public String updateRecord(Employee employee) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("raj");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Employee employee1=entityManager.find(Employee.class, employee.getEmplNum());
		if(employee1!=null)
		{
			entityTransaction.commit();
		    return "update Successfully";
		
		}
		else {
		return "object not found";
		}
	}

	@Override
	public String deleteRecord(Integer emplNum)
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("raj");
	    EntityManager entityManager=entityManagerFactory.createEntityManager();
	    Employee employee=entityManager.find(Employee.class,emplNum );
	   if(employee!=null)
	   {
		   EntityTransaction entityTransaction=entityManager.getTransaction();
		   
		     entityTransaction.begin();
		     entityManager.remove(employee);
		     entityTransaction.commit();
			 entityManagerFactory.close();
			 return "Delete Successfully...";
	   }
	   else {
		return "object not found";
		}
	
	}

	@Override
	public Employee showRecord(Integer emplNum) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("raj");
	    EntityManager entityManager=entityManagerFactory.createEntityManager();
	    Employee employee=entityManager.find(Employee.class,emplNum );
		return employee;
	}

}
