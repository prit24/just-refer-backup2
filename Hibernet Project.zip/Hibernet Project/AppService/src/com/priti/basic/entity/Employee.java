package com.priti.basic.entity;

import javax.persistence.*;
@Entity
@Table(name= "employee")
public class Employee 
{
	@Id
	@Column(name = "eno")
	private Integer emplNum;
    private String emplName;
    private Float emplSal;          
	
    
    public Integer getEmplNum() 
	{
		return emplNum;
	}
	public void setEmplNum(Integer emplNum) 
	{
		this.emplNum = emplNum;
	}
	public String getEmplName()
	{
		return emplName;
	}
	public void setEmplName(String string)
	{
		this.emplName = string;
	}
	public Float getEmplSal() 
	{
		return emplSal;
	}
	public void setEmplSal(Float emplSal)
	{
		this.emplSal = emplSal;
	}
}
