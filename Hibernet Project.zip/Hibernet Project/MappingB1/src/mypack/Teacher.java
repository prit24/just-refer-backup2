package mypack;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
@Entity
public class Teacher 
{      
	    @Id
       private Integer teacherId;
       private String teacherName;
       private String email;
       @OneToMany(cascade = CascadeType.ALL)
       @JoinColumn(name="")
       private List<Students> students;
	   public Integer getTeacherId() 
	   {
	  	return teacherId;
    	}
	   public void setTeacherId(Integer teacherId) 
	   {
		this.teacherId = teacherId;
	   }
	   public String getTeacherName()
	   {
		return teacherName;
	   }
	   public void setTeacherName(String teacherName) 
	   {
		this.teacherName = teacherName;
	   }
	   public String getEmail() 
	   {
		return email;
	   }
	   public void setEmail(String email)
	   {
		this.email = email;
	    }
	   public List<Students> getStudents()
	   {
		return students;
	   }
	   public void setStudents(List<Students> students)
	   {
		this.students = students;
	    }
}
