package mypack;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.ManyToAny;
@Entity
public class Students 
{
	    @Id
        private Integer studentId;
        private String studentName;
        private Integer studentAge;
		@ManyToOne(cascade = CascadeType.ALL)
	
		private Teacher teacher;
		public Integer getStudentId() 
		{
			return studentId;
		}
		public void setStudentId(Integer studentId) 
		{
			this.studentId = studentId;
		}
		public String getStudentName() 
		{
			return studentName;
		}
		public void setStudentName(String studentName) 
		{
			this.studentName = studentName;
		}
		public Integer getStudentAge() 
		{
			return studentAge;
		}
		public void setStudentAge(Integer studentAge) 
		{
			this.studentAge = studentAge;
		}
		public Teacher getTeacher() 
		{
			return teacher;
		}
		
	
}
