package mypack;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp2Update
{

	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter The Student Id");
		Integer studentsId=scanner.nextInt();
		
		System.out.println("Enter The Student Name");
		String studentsName=scanner.next();
		
		System.out.println("Enter The Student Age");
		Integer studentsAge=scanner.nextInt();
		
		
		
		System.out.println("Enter The Teacher Name");
		String teacherName=scanner.next();
		

		System.out.println("Enter The Teacher Email");
		String teacherEmail=scanner.next();
		
		 Students students2= entityManager.find(Students.class, studentsId);
		Teacher teacher=new Teacher();
		if(students2!=null) 
		{
			
			entityTransaction.begin();
			teacher.setTeacherName(teacherName);
			teacher.setEmail(teacherEmail);
						
			List<Students> students=teacher.getStudents();
		   
			
			
			entityTransaction.commit();
			System.out.println("Student updated");
			
				
		}
		else
		{
			System.out.println("Student not found");
		}
		entityManager.close();
		entityManagerFactory.close();

}
}