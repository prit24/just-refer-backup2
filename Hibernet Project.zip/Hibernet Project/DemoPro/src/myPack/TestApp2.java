package myPack;

import java.util.Scanner;
import javax.persistence.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

public class TestApp2 {

	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter empNo:");
		Integer empNo = scanner.nextInt();
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("raj");
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Employee employee = entityManager.find(Employee.class,empNo);
		
		System.out.println("No is:" + employee.getEmplNum());
		System.out.println("Name is:" + employee.getEmplName());
		System.out.println("Salary is:" + employee.getEmplSal());
		
		entityManager.close();
		entityManagerFactory.close();
		System.out.println("show");

	}

	}