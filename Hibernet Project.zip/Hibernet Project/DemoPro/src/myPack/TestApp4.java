package myPack;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp4 {
	public static void main(String[] args) {	
	
		int choice;
		
		Scanner scanner =  new Scanner(System.in);
		
		Integer empNo_1;
	
		String empName; 
		
		Float empSal;
		char yesNo = 0;
		Employee employee = new Employee();
		
		
				EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("raj");
				EntityManager entityManager = entityManagerFactory.createEntityManager();
				EntityTransaction entityTransaction = entityManager.getTransaction();
				
				
				do {

					System.out.println("Employee Management System");
					System.out.println("1.Enter new Record");
					System.out.println("2.Update Record");
					System.out.println("3.Delete Record");
					System.out.println("4.Display Record");
					System.out.println("5.Exit");
					System.out.println("Enter your choice:: ");
					choice   = scanner.nextInt();
						
		switch(choice)
		{
		case 1:
			
			
			System.out.println("------Enter Employee Data------");
			System.out.println("Enter Employee Number:: ");
			 empNo_1 = scanner.nextInt();
			System.out.println("Enter Employee Name:: ");
			 empName = scanner.next(); 
			System.out.println("Enter Employee Salary:: ");
			 empSal = scanner.nextFloat();
					//entityManager.find(Employee.class, empNO);
					//System.out.println(" Employee Salary:: "+employee.getEmpSal());
				
				employee.setEmplName(empName);
				employee.setEmplNum(empNo_1);
				employee.setEmplSal(empSal);
					entityTransaction.begin();
					entityManager.persist(employee);
					entityTransaction.commit();
					System.out.println("Saved");
					
			
			
		    break;
		  case 2:
			  	System.out.println("Update exesiting recrd");
			  	System.out.println("Enter Employee Number:: ");
				 empNo_1 = scanner.nextInt();
				System.out.println("Enter Employee Name:: ");
				 empName = scanner.next(); 
				System.out.println("Enter Employee Salary:: ");
				 empSal = scanner.nextFloat();
				Employee employee1 = entityManager.find(Employee.class, empNo_1);
			  	  
			  	  if(employee1!=null)
						{
						
						entityTransaction.begin();
						employee1.setEmplName(empName);
						employee1.setEmplSal(empSal);
						entityTransaction.commit();
						System.out.println("Record updated succesfully!!");
						}
						else {
							System.out.println("Record not found!!!!");
							
						}
		    break;
		    
		  case 3:
			  if(employee!=null)
				{
				//EntityTransaction entityTransaction = entityManager.getTransaction();
				  System.out.println("Enter Employee Number:: ");
					 empNo_1 = scanner.nextInt();
				Employee employee2 = entityManager.find(Employee.class, empNo_1);
				entityTransaction.begin();
				entityManager.remove(employee2);
				entityTransaction.commit();
				System.out.println("Record removed succesfully!!");
				}
				else {
					System.out.println("Record not found!!!!");
	
				}
		    break;
		    
		  case 4:
			  	System.out.println("Employee Details");
			  	System.out.println("Enter employee number::");
				 empNo_1 = scanner.nextInt();
				Employee employee3 = entityManager.find(Employee.class, empNo_1);
				System.out.println(" Employee Number:: "+employee3.getEmplNum());
				System.out.println(" Employee Name:: "+employee3.getEmplName());
				System.out.println(" Employee Salary:: "+employee3.getEmplSal());
				break;
					 
			 }
		System.out.println("Do you want to continue....Y/N:");
		yesNo = scanner.next().charAt(0);
		 
		}
	
	while(yesNo=='Y'|| yesNo=='y');
		
		entityManager.close();
		entityManagerFactory.close();
		}
	}
