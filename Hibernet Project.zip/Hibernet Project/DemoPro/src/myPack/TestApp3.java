package myPack;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp3 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter empNo:");
		Integer empNo = scanner.nextInt();
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("raj");
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Employee employee = entityManager.find(Employee.class,empNo);
		
		if(employee != null) {
			EntityTransaction entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			employee.setEmplName("Priti");
			employee.setEmplSal(4567.89F);
			entityTransaction.commit();
			System.out.println("updated");
			
		}
		else {
			System.out.println("object not found");
		}
		
		
		entityManager.close();
		entityManagerFactory.close();
		System.out.println("show");

	}

}