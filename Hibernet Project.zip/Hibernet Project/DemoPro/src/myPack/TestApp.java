package myPack;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.*;


public class TestApp {

	
		public static void main(String[] args)
		{
		    Scanner scanner = new Scanner(System.in);
		    {
				System.out.println("Enter The Number");
				Integer emplNum=scanner.nextInt();
				
				System.out.println("Enter The Name");
				String emplName=scanner.next();
				
				System.out.println("Enter The Salary");
				Float emplSal=scanner.nextFloat();
				
				Employee employee=new Employee();
				employee.setEmplNum(emplNum);
				employee.setEmplName(emplName);
				employee.setEmplSal(emplSal);
				
				EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("raj");
				EntityManager entityManager=entityManagerFactory.createEntityManager();
				EntityTransaction entityTransaction=entityManager.getTransaction();
				
				entityTransaction.begin();
				entityManager.persist(employee);
				entityTransaction.commit();
				entityManager.clear();
				entityManagerFactory.close();
			}
		    
		    System.out.println("Save The Object...");
		}

	}