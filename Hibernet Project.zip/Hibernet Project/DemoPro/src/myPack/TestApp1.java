package myPack;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee no ");
		Integer empNo = sc.nextInt();
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("raj");
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		Employee employee=entityManager.find(Employee.class, empNo);
		if(employee!=null) {
			entityManager.remove(employee);
			System.out.println("Employee removed");
			EntityTransaction entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			entityTransaction.commit();
			
		}
		else {
			System.out.println("Employee not found");
		}
		entityManager.close();
		entityManagerFactory.close();
		
	}
	

}