package mypack;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp1 
{

	public static void main(String[] args)
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Students students1=new Students();
		Students students2=new Students();
		Students students3=new Students();
		
        students1.setStudentId(32);
        students1.setStudentName("shrisha");
        students1.setStudentAge(22);
        
        students2.setStudentId(42);
        students2.setStudentName("Prisha");
        students2.setStudentAge(23);
        
        students3.setStudentId(40);
        students3.setStudentName("Tanishka");
        students3.setStudentAge(22);
        
        List studentInfo=List.of(students1, students2,students3);
        
        Teacher teacher=new Teacher();
        teacher.setTeacherId(997);
        teacher.setTeacherName("Rajeev");
        teacher.setEmail("rajeev@gmail.com");
        teacher.setStudents(studentInfo);
        
        entityTransaction.begin();
        entityManager.persist(teacher);
        entityTransaction.commit();
        entityManager.close();
        entityManagerFactory.close();
        System.out.println("Save Object....");
        
	}

}
