package com.priti.library.exception;

public class InvalidInputException {

}
