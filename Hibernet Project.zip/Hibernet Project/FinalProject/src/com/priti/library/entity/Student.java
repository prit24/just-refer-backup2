package com.priti.library.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer studId;
    @Column(length = 20)
    private String studName;
    @Column(length = 20)
    private String studEmail;
    @Column(length = 10)
    private String studContactNo;
    @Column(length = 20)
    private String studAddress;
    @Column(length = 20)
    private String studPassword;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "student")
    private List<BookIssue> bookIssue;

    public Integer getStudId() {
        return studId;
    }

    public void setStudId(Integer studId) {
        this.studId = studId;
    }

    public String getStudName() {
        return studName;
    }

    public void setStudName(String studName) {
        this.studName = studName;
    }

    public String getStudEmail() {
        return studEmail;
    }

    public void setStudEmail(String studEmail) {
        this.studEmail = studEmail;
    }

    public String getStudContactNo() {
        return studContactNo;
    }

    public void setStudContactNo(String studContactNo) {
        this.studContactNo = studContactNo;
    }

    public String getStudAddress() {
        return studAddress;
    }

    public void setStudAddress(String studAddress) {
        this.studAddress = studAddress;
    }

    public String getStudPassword() {
        return studPassword;
    }

    public void setStudPassword(String studPassword) {
        this.studPassword = studPassword;
    }

    public List<BookIssue> getBookIssue() {
        return bookIssue;
    }

    public void setBookIssue(List<BookIssue> bookIssue) {
        this.bookIssue = bookIssue;
    }
}