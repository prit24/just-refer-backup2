package com.priti.library.presentation;

import java.util.Scanner;
public class Main {

	public static void main(String[] args){
		StudentUser studentUser=new StudentUserImpl();
        BookIssueUser bookIssueUser=new BookIssueUserImpl();
        BookUser bookUser=new BookUserImpl();
	    Integer choice=0;
	    String adminId,password;
	    Boolean login;
	    Scanner scanner=new Scanner(System.in);
        while(choice!=3)
        {
    	System.out.println("-------------------------");
    	System.out.println("Wel-Come To Library");
    	System.out.println("-------------------------");
    	System.out.println("1. Admin ");
    	System.out.println("2. Student ");
    	System.out.println("3. Exist");
    	
    	System.out.println("-------------------------");
    	System.out.println("Enter the choice:");
    	choice =scanner.nextInt();			
    	switch(choice)
    	{
    	case 1:
    		System.out.println("Enter Admin User Id:");
    		adminId=scanner.next();
    		System.out.println("Enter Admin User Password:");
    		password=scanner.next();
    		if(adminId.equals("admin")&& password.equals("pass")) 
    		{
    	
	    while(choice!=8)
	    {
	    	System.out.println("-------------------------");
	    	System.out.println("Wel-Come Admin");
	    	System.out.println("--------------------------");
	    	System.out.println("1. Add Book");
	    	System.out.println("2. Update Stock ");
	    	System.out.println("3. Search Book");
	    	System.out.println("4. Confirm Book-Issue");
	    	System.out.println("5. Display Unreturned Book");
	    	System.out.println("6. Display UnIssued Book");
	    	System.out.println("7. Display Fine Details");
	    	System.out.println("8. Logout"); 
	    	System.out.println("Enter the choice:");
	    	choice =scanner.nextInt();
	    	
	    	
	    	switch(choice)
	    	{
		    case 1:
		    	bookUser.inputGetBookById();;
		    	break;
		    case 2: 
		    	while(choice!=5)
			    {
		    		System.out.println("----------------------------------");
					System.out.println("Choose one for Update book: ");
					System.out.println("----------------------------------");
					System.out.println("1.Get Book by Id");
			    	
			    	switch(choice)
			    	{
			    	case 1:
				    
				    	bookUser.inputUpdateStock();
				    	break;
				    
			    	}//case 1: => case 3: Switch end		    	
			    } //case 1: => case 3: while end
		    	//bookUser.inputUpdateStock();
		    	
		    	break;
		    case 3: 	
		    	while(choice!=5)
			    {
		    		System.out.println("\n------------Menu-----------");
                    System.out.println("1. View All Books ");
                    System.out.println("2. Search by Book Name");
                    System.out.println("3. Search by Book Type");
                    System.out.println("4. Search by Author");
                    System.out.println("5.Logout ");
                    System.out.print("\nPlease enter your choice (1-5) : ");
                    int choice1 = scanner.nextInt();

                    // display book for admin switch ---------------------

                    switch (choice1)
                    {
                        case 1:bookUser.inputGetAllBooks();
                            break;
                        case 2:bookUser.inputGetBookByName();
                            break;
                        case 3:bookUser.inputGetBookByType();
                            break;
                        case 4:bookUser.inputGetBookByAuthor();
                            break;
                        case 5:
                            System.out.println("Logout");
                            return;
                    }
                    break;
                    
			    }

		    	
		    case 4:	
		    	bookIssueUser.inputConfirmIssueBook();
		    	break;
		    case 5:
		    	//
		    	break;
		    case 6:
		    	//
		    	break;
		    case 7:
		    	//
		    	break;
		    case 8:
		    	System.out.println("Admin Logout Successfully");
		    	//System.exit(0);
		    	break;
			}//Admin case 1: switch end
	    	
	    }//Admin case 1: while end
	    	 
    		}else {
    			System.out.println("Id & Password incorrect");
    		}
    		 break;
    	   case 2:
    		   System.out.println("------------------------------");
    		   System.out.println("1. Register Student");
    		   System.out.println("2. Login Student");
    		   System.out.println("------------------------------");
    		   System.out.println("Enter the choice:");
    	       choice =scanner.nextInt();
    	       switch (choice) {
			case 1:
				studentUser.addStudent();
				//break;

			case 2:
				login=studentUser.inputStudentLogin();
				if(login=true) {
					while(choice!=10)
				    {
				    	System.out.println("------------------------------");
				    	System.out.println("Wel-Come Student");
				    	System.out.println("------------------------------");
						System.out.println("1. Search Book");
						System.out.println("2. Issue Book");
						System.out.println("3. Return Book");
						System.out.println("4. View Book issue Details");
						System.out.println("5. View Fine Details");
						System.out.println("6. View Profile");
						System.out.println("7. Pay fine");
						System.out.println("8. Show All Book");
						System.out.println("9. Logout");
				    	choice =scanner.nextInt();		
				    	switch(choice)
				    	{
					    case 1: 	
					    	while(choice!=4)
						    {
					    		System.out.println("----------------------------------");
								System.out.println("Choose one for searching book: ");
								System.out.println("----------------------------------");
								System.out.println("1.Get Book by Name");
								System.out.println("2.Get Book by Type");
								System.out.println("3.Get Book by Author");
						    	System.out.println("4.Exit.. ");
						    	choice =scanner.nextInt();		
						    	switch(choice)
						    	{
							    case 1:
							    	studentUser.getStudentById();
							    	break;
							    case 2: 	
							    	bookUser.inputGetBookByType();
							    	break;
							    case 3: 	
							    	bookUser.inputGetBookByAuthor();
							    	break;
							    case 4:
							    	System.out.println("Exit");
							    	break;
						    	}//Main case 2: => case 1: switch end				    	
						    } //Main case 2: => case 1: while end
					    	 break;
					    case 2: 	
					    	studentUser.bookIssue();
					    	break;
					    case 3:	
					    	bookIssueUser.inputReturnBook();
					    	break;
					    case 4:
					    	
					    	bookIssueUser.displayUnissuedBook();
					    	break;
					    case 5:
					    	//
					    	break;
					    case 6:
					    	studentUser.getStudentById();
					    	break;
					    case 7:
					    	//
					    	break;
					    case 8:
					    	bookUser.inputGetAllBooks();
					    	break;
					    case 9:
					    	System.out.println("Student Logout");
					    	System.exit(0);
					    	
						}//case 2: switch end
				    	
				    }//case 2: while end
					
				    System.out.println("Do you want to continue");
				    String ch1=scanner.next();
					if(ch1.equals("no")) 
					{
						System.out.println("user does not want to continue");
						System.out.println("thank you!!");
						System.exit(0);
						}	  
				   break;	
				}//Student case 2: if end
				
			}//Student case 2: Switch end
    	       break;
    		
    	   case 3:
    		   System.out.println("Thank you!!");
    		   System.exit(0);
    		   break;
    	}//Main switch end	
       }//Main while end    
        }
	
}