package com.priti.library.presentation;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.priti.library.entity.Book;
import com.priti.library.entity.BookIssue;
import com.priti.library.entity.Student;
import com.priti.library.service.BookIssueService;
import com.priti.library.service.BookIssueServiceImpl;
import com.priti.library.service.BookService;
import com.priti.library.service.BookServiceImpl;
import com.priti.library.service.StudentService;
import com.priti.library.service.StudentServiceImpl;

import javassist.bytecode.Descriptor.Iterator;

public class BookIssueUserImpl implements BookIssueUser
{
	private Scanner scanner=new Scanner(System.in);
	private BookIssueService bookIssueService=new BookIssueServiceImpl();
	private BookService bookService=new BookServiceImpl();
	private StudentService studentService=new  StudentServiceImpl(); 
	private Integer bookId;
	
	@Override
	public void inputIssueBook(Integer studentId) {
		System.out.println("BookIssueUserImpl"+studentId);
		System.out.println("Enter the book Id");
		bookId=scanner.nextInt();
		
		Book book1=bookService.getBookById(bookId);
		Student student1 =studentService.getStudentById(studentId);
		BookIssue bookIssue = new BookIssue();
		bookIssue.setBook(book1);
		bookIssue.setStudent(student1);
		bookIssue.setIssueDate(bookIssue.getIssueDate());
		bookIssue.setDueDate(bookIssue.getDueDate());
		bookIssue.setReturnDate(bookIssue.getReturnDate());
		bookIssue.setBookStatus(bookIssue.getBookStatus());
		bookIssue.setFine(bookIssue.getFine());
		System.out.println(bookIssueService.issueBook(bookIssue));
	
		/*
		 * 
		 LocalDate issueDate = LocalDate.now();
		 
	     System.out.println("Issued Date: " + issueDate);
        
	     LocalDate  returnDate= issueDate.plusDays(5);
	     System.out.println("Return Date: " + returnDate);
        
	     LocalDate dueDate = returnDate.plusDays(1);
	     System.out.println("Due Date: " + dueDate);
	     
	     System.out.println("Enter the Book Status:");
	     String bookStatus = scanner.next();

        // Creating a new BookIssue object and setting its properties
        BookIssue bookIssue = new BookIssue();
        bookIssue.setIssueDate(issueDate);
        bookIssue.setReturnDate(returnDate);
        bookIssue.setDueDate(dueDate);
        bookIssue.setBookStatus(bookStatus);
 
        System.out.println(bookIssueService.issueBook(bookIssue));
        */
    }
	@Override
	public void inputReturnBook() {
		LocalDate issueDate = LocalDate.now();
        System.out.println("Enter the Issue ID to return the book:");
        int issueId = scanner.nextInt();

        
        // Retrieve existing BookIssue details based on the issue ID
        BookIssue bookIssue= bookIssueService.getBookIssuedById(issueId);

        if (bookIssue != null) {
            LocalDate returnDate = issueDate.plusDays(5);
            System.out.println("Return Date: " + returnDate);

            System.out.println("Enter the Book Status:");
            String bookStatus = scanner.next();

            // Update the return date and book status
            bookIssue.setReturnDate(returnDate);
            bookIssue.setBookStatus(bookStatus);
            System.out.println(bookIssueService.issueBook(bookIssue));
        }
	}
	@Override
	public void inputGetIssuedBook() {
			List<BookIssue> l=bookIssueService.getIssuedBook();
			java.util.Iterator<BookIssue> itr=l.iterator();
			System.out.println("---------------------------------------------------------------");
			System.out.println("IssueId\tIssueDate\tReturnDate\tDueDate\tBookStatus");
			System.out.println("---------------------------------------------------------------");
			System.out.println();
			while(itr.hasNext())
			{
				BookIssue b=itr.next();
				System.out.println(b.getIssueId()+"\t"+b.getIssueDate()+"\t"+b.getReturnDate()+"\t"+b.getDueDate()+"\t"+b.getBookStatus());
				System.out.println("------------------------------------------------------------------------------");
			}
							
	}
	@Override
	public void inputgetBookIssuedById() {System.out.println("Enter the BookIssue Id:");
	Integer issueId=scanner.nextInt();
	BookIssue bookIssue=bookIssueService.getBookIssuedById(issueId);
	 if(bookIssue!=null) 
 	    {
		 
 	    System.out.println("Book Id is:" +bookIssue.getIssueId());
 	    System.out.println("Book Name is:" +bookIssue.getIssueDate());
 	    System.out.println("Book Author Name is:" +bookIssue.getReturnDate());
 	    System.out.println("Book Quentity is:" +bookIssue.getDueDate());
 	    System.out.println("Book Type is:" +bookIssue.getBookStatus());
 	   
 	    }
 	    else {
 	    	System.out.println("BookIssued not found......");
 	    }
		
	}
	@Override
	public void inputConfirmIssueBook() {
		displayUnissuedBook();
		System.out.println("Do you want to issue any book to the student(yes/no)");
		String ans=scanner.next();
		if(ans.equalsIgnoreCase("YES")) {
			System.out.println("Enter IssueId:");
			
			Integer issuId=scanner.nextInt();
			BookIssue bookIssue= bookIssueService.findRecordByIssueId(issuId);
			bookIssue.setIssueDate(LocalDate.now());
			bookIssue.setDueDate(LocalDate.now().plusDays(5));
			bookIssue.setBookStatus("ISSUED");
			
			Book book=bookService.getBookById(bookIssue.getIssueId());
			book.setQuantity(book.getQuantity()-1);
			bookService.updateStock(book);
			
			System.out.println(bookIssueService.confirmIssueBook(bookIssue));
		}
		
	}
	
//	  List<BookIssue> list=	bookIssueService.displayUnissuedBook();
//	 if(list==null) {
//		 System.out.println("No Book Is Available for Confirm");
//	 }
//		else {
//		for(BookIssue bi:list){
//			System.out.println(bi.getIssueId()+" "+bi.getBook().getBookId()+" "+bi.getStudent().getStudentId()+" "+bi.getBookStatus()+" "+bi.getBook().getBookName()+" "+bi.getStudent().getStudentName());
//		}
//	}
	@Override
	public void displayUnissuedBook() {
	    List<BookIssue> list = bookIssueService.displayUnissuedBook();
	    if (list == null) {
	        System.out.println("No book available for confirmation");
	    } else {
	        for (BookIssue bi : list) {
	            System.out.println(bi.getIssueId() + " " + bi.getBook().getBookId() + " " + bi.getStudent().getStudId()
	                    + " " + bi.getBook().getBookId() + " " + bi.getBook().getBookName() + " "
	                    + bi.getStudent().getStudName());
	        }
	    }
	}


}
