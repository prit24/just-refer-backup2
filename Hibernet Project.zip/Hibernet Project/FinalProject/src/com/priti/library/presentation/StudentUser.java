package com.priti.library.presentation;
import com.priti.library.entity.Student;
public interface StudentUser
{
	void addStudent();
	void getStudentById();
	boolean inputStudentLogin();
	void bookIssue();
	
}