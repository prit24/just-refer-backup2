package com.priti.library.presentation;

import com.priti.library.entity.Student;
import com.priti.library.service.StudentService;
import com.priti.library.service.StudentServiceImpl;

import java.util.Scanner;

public class StudentUserImpl implements StudentUser
{
	private Scanner scanner=new Scanner(System.in);
	private StudentService studentService=new StudentServiceImpl();
	private BookUser bookUser=new BookUserImpl();
	private BookIssueUser bookIssueUser=new BookIssueUserImpl();
	private Integer studentId;
	private String password;
	@Override
	public void addStudent() {
		System.out.println("Enter the student Name:");
		String studentName=scanner.next();
		System.out.println("Enter the Student Email:");
		String studentEmail=scanner.next();
		System.out.println("Enter the Student ContactNo:");
		String studentContactNo=scanner.next();
		System.out.println("Enter the Student Address:");
		String studentAddress=scanner.next();
		System.out.println("Enter the Student Password:");
		String password=scanner.next();
		
		
		Student student=new Student();
		student.setStudName(studentName);
		student.setStudEmail(studentEmail);
		student.setStudContactNo(studentContactNo);
		student.setStudAddress(studentAddress);
		student.setStudPassword(password);
		
		System.out.println(studentService.addStudent(student));
	}

		@Override
	public void getStudentById() {
		System.out.println("Enter the Student Id:");
		Integer studentId=scanner.nextInt();
		Student student=studentService.getStudentById(studentId);
		 if(student!=null) 
		 {
			 System.out.println("---------------------------------------------------------------"); 
			 System.out.println("StudentId\tStudentName\tStudentEmail\tStudentContactNo\tStudentAddress");
			 System.out.println("-------------------------------------------------------------");
				 
			 System.out.println(student.getStudId()+"\t  "+student.getStudContactNo()+"\t "+student.getStudAddress());
		 	    }
		 else {
	 	    	System.out.println("Student not found......");
	 	    }
	}

	@Override
	public boolean inputStudentLogin() {
		System.out.println("Enter the Student Id:");
		 studentId=scanner.nextInt();
		System.out.println("Enter the Student password:");
		 password=scanner.next();
		return true;
	}

	@Override
	public void bookIssue() {
		bookUser.inputGetAllBooks();
		System.out.println("StudentUserImpl"+studentId);
		bookIssueUser.inputIssueBook(studentId);
		
	}


}