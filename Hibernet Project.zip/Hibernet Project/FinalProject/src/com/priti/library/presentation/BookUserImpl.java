package com.priti.library.presentation;

import java.util.List;
import java.util.Scanner;

import com.priti.library.entity.Book;
import com.priti.library.service.BookService;
import com.priti.library.service.BookServiceImpl;

import javassist.bytecode.Descriptor.Iterator;

public class BookUserImpl implements BookUser{
	private Scanner scanner=new Scanner(System.in);
	private BookService bookService=new BookServiceImpl();
	
	@Override
	public void inputAddBook() {
		 System.out.println("------------------------------------------------------------");
	        System.out.printf("| %-6s | %-20s | %-15s | %-10s | %-8s |\n",
	                "BookId", "BookName", "AuthorName", "BookType", "Quantity");
	        System.out.println("------------------------------------------------------------");

		System.out.println("Enter the Book Name:");
		String bookName=scanner.next();
		System.out.println("Enter the Book Auther Name:");
		String autherName=scanner.next();
		System.out.println("Enter the Book Quantity:");
		int bookQuentity=scanner.nextInt();
		System.out.println("Enter the Book Type:");
		String bookType=scanner.next();
		
		Book book=new Book();
		book.setBookName(bookName);
		book.setAuthorName(autherName);
		book.setBookType(bookType);
		book.setQuantity(bookQuentity);
//		book.setBookIssue(null);
	
		BookService bookService=new BookServiceImpl();
		
		System.out.println(bookService.addBook(book));
	}

	@Override
	public void inputGetAllBooks() {
			List<Book> l=bookService.getAllBooks();
			java.util.Iterator<Book> itr=l.iterator();
			
			 System.out.println("------------------------------------------------------------");
		        System.out.printf("| %-6s | %-20s | %-15s | %-10s | %-8s |\n",
		                "BookId", "BookName", "AuthorName", "BookType", "Quantity");
		        System.out.println("------------------------------------------------------------");

			while(itr.hasNext())
			{
				Book b=itr.next();
				System.out.println(b.getBookId()+"\t  "+b.getBookName()+"\t       "+b.getAuthorName()+"\t "+b.getBookType()+"\t "+b.getQuantity());
			}
				
	}

	@Override
	public void inputGetBookById() {
		System.out.println("Enter the Book Id:");
		Integer bookId=scanner.nextInt();
		Book book=bookService.getBookById(bookId);
		 if(book!=null) 
	 	    {
			 System.out.println("------------------------------------------------------------");
		        System.out.printf("| %-6s | %-20s | %-15s | %-10s | %-8s |\n",
		                "BookId", "BookName", "AuthorName", "BookType", "Quantity");
		        System.out.println("------------------------------------------------------------");

			 
			 System.out.println(book.getBookId()+"\t  "+book.getBookName()+"\t       "+book.getAuthorName()+"\t "+book.getBookType()+"\t "+book.getQuantity());
	 	    }
		 else {
	 	    	System.out.println("Book Id not found");
	 	    }
        }
	
	@Override
	public void inputGetBookByName() {
		System.out.println("Enter the Book Name:");
        String bookName = scanner.next();

        List<Book> books = bookService.getBookByName(bookName);

        if (books.isEmpty()) {
            System.out.println("Book not found");
        } else {
        	for (Book book : books) {
        		
        		 System.out.println("------------------------------------------------------------");
        	        System.out.printf("| %-6s | %-20s | %-15s | %-10s | %-8s |\n",
        	                "BookId", "BookName", "AuthorName", "BookType", "Quantity");
        	        System.out.println("------------------------------------------------------------");

    			System.out.println(book.getBookId()+"\t  "+book.getBookName()+"\t       "+book.getAuthorName()+"\t "+book.getBookType()+"\t "+book.getQuantity());
 	    }
        }
	}

	@Override
	public void inputGetBookByType() {
		System.out.println("Enter the Book Type:");
        String bookType = scanner.next();

        List<Book> books = bookService.getBookByType(bookType);

        if (books.isEmpty()) {
            System.out.println("Book not found");
        } else {
        	 System.out.println("------------------------------------------------------------");
             System.out.printf("| %-6s | %-20s | %-15s | %-10s | %-8s |\n",
                     "BookId", "BookName", "AuthorName", "BookType", "Quantity");
             System.out.println("------------------------------------------------------------");

        	for (Book book : books) {
        	System.out.println(book.getBookId()+"\t  "+book.getBookName()+"\t       "+book.getAuthorName()+"\t "+book.getBookType()+"\t "+book.getQuantity());
        	}
 	    }
	}
	@Override
	public void inputUpdateStock() {
		System.out.println("Enter the Book Id::");	    
 	    Integer bookId =scanner.nextInt();
 	    System.out.println("Enter the Book Quantity::");	    
 	    Integer quantity =scanner.nextInt();
 	    
 	    Book book=new Book();
 	   
 	    book.setBookId(bookId);
 	    book.setQuantity(quantity);
 	   System.out.println(bookService.updateStock(book));
	}

	@Override
	public void inputGetBookByAuthor() {
		System.out.println("Enter the Book Author:");
        String authorName = scanner.next();

        List<Book> books = bookService.getBookByAuthor(authorName);

        if (books.isEmpty()) {
            System.out.println("Book not found");
        } else {
        	for (Book book : books) {
        		 System.out.println("------------------------------------------------------------");
        	        System.out.printf("| %-6s | %-20s | %-15s | %-10s | %-8s |\n",
        	                "BookId", "BookName", "AuthorName", "BookType", "Quantity");
        	        System.out.println("------------------------------------------------------------");

 			System.out.println(book.getBookId()+"\t  "+book.getBookName()+"\t       "+book.getAuthorName()+"\t "+book.getBookType()+"\t "+book.getQuantity());
       
        	}
        }
        }
		
	}

