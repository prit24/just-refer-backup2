package com.priti.library.presentation;

public interface BookIssueUser 
{
     void inputIssueBook(Integer studentId);
 	void inputReturnBook();
 	void inputGetIssuedBook();
 	void inputgetBookIssuedById();
 	void inputConfirmIssueBook();
// 	void findRecordByIssueId(Integer issueId);
 	void displayUnissuedBook();
}
