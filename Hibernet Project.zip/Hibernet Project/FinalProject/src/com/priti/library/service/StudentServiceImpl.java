package com.priti.library.service;

import com.priti.library.dao.StudentDao;
import com.priti.library.dao.StudentDaoImpl;
import com.priti.library.entity.Student;

public class StudentServiceImpl implements StudentService
{
	private StudentDao studentDao=new StudentDaoImpl();

	@Override
	public String addStudent(Student student) {
		return studentDao.addStudent(student);
	}

	@Override
	public Student getStudentById(Integer studentId) {
		return studentDao.getStudentById(studentId);
	}

	@Override
	public void payFine(Student student1)
	{

/*
		
	    bookIssueList = bookIssueDao.getStudentFineDetail(student1);
		
		
	    if(bookIssueList==null) 
		{
			System.out.println("Something went wrong");
		}
		else if(bookIssueList.isEmpty())
		{
			System.out.println("Student fine is null");
		}
		else
		{	
			BookIssueServiceImpl.showBookIssuedToStudent();
			Double studentTotalFine = student1.getStudentTotalFine();
			System.out.println("Your Total fine is "+studentTotalFine);
			
			if(studentTotalFine>0)
			{
				do {
					System.out.print("\nWould you like to pay your fine ? (yes/no) : ");
					ch = scanner.nextLine();
					if(ch.equalsIgnoreCase("yes"))
					{
						do {
							System.out.print("Please Enter valid amount : ");
							fineKiAmt = scanner.nextLine();
							if(myValidation.isIdNumeric(fineKiAmt))
							{
								fineAmt = Double.parseDouble(fineKiAmt);
								if(fineAmt>0 && fineAmt<=studentTotalFine) 
								{
									studentTotalFine -= fineAmt;
									studentDao.updateStudentTotalFine(student1,studentTotalFine);
									System.out.println("Now Your fine is "+studentTotalFine);
									break;
								}
							}
							System.out.println("Please Enter valid Amount!");
						}while(true);
					}
					else if(ch.equalsIgnoreCase("no")) break;
					else System.out.println("Please Enter yes or no !");
			
				}while(student1.getStudentTotalFine()>0);
			}
			else 
				System.out.println("Student fine is null");
		}	
	}

*/
	}
}