package com.priti.library.service;

import java.util.List;

import com.priti.library.entity.BookIssue;

public interface BookIssueService 
{
	 public String issueBook(BookIssue bookIssue);
	 public String returnBook(BookIssue bookIssue);
	 BookIssue getBookIssuedById(Integer issueId);
	List<BookIssue> getIssuedBook();
//	void inputConfirmIssueBook();
	List<BookIssue> displayUnissuedBook();
	 BookIssue findRecordByIssueId(Integer issueId);
	 String confirmIssueBook(BookIssue bookIssue);

}