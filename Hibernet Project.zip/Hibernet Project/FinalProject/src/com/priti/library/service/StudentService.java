package com.priti.library.service;

import com.priti.library.entity.Student;

public interface StudentService
{
	String addStudent(Student student);
	Student getStudentById(Integer studentId);
	void payFine(Student student1);


}