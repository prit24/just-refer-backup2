package com.priti.library.service;

import java.util.List;

import com.priti.library.dao.BookIssueDao;
import com.priti.library.dao.BookIssueDaoImpl;
import com.priti.library.entity.BookIssue;

public class BookIssueServiceImpl implements BookIssueService
{
	private BookIssueDao bookIssueDao = new BookIssueDaoImpl();
	 
	@Override
	public String issueBook(BookIssue bookIssue) {
		
		return bookIssueDao.issueBook(bookIssue);
	}
	

	@Override
	public String returnBook(BookIssue bookIssue) {
		return bookIssueDao.returnBook(bookIssue);
		
	}
	
	
	@Override
	public BookIssue getBookIssuedById(Integer issueId) {
		// TODO Auto-generated method stub
		return bookIssueDao.getBookIssuedById(issueId);
	}

	
	@Override
	public List<BookIssue> getIssuedBook() {
		// TODO Auto-generated method stub
		return bookIssueDao.getIssuedBook();
	}


//	@Override
//	public void inputConfirmIssueBook() {
////		return bookIssueDao.get();
//		
//	}


	@Override
	public List<BookIssue> displayUnissuedBook() {
		
		return bookIssueDao.displayUnissuedBook();
	}


	@Override
	public BookIssue findRecordByIssueId(Integer issueId) {
		
		return bookIssueDao.findRecordByIssueId(issueId);
	}


	@Override
	public String confirmIssueBook(BookIssue bookIssue) {
		
		return bookIssueDao.confirmIssueBook(bookIssue);
	}

	

}