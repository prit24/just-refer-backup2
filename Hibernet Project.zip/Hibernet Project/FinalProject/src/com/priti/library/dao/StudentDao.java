package com.priti.library.dao;

import com.priti.library.entity.Student;
public interface StudentDao
{
	String addStudent (Student student);
	Student getStudentById(Integer studentId);
	Integer updateStudentTotalFine(Student student1, Double studentTotalFine1);
}