package com.priti.library.dao;

import java.util.List;

import com.priti.library.entity.BookIssue;
import com.priti.library.entity.Student;

public interface BookIssueDao 
{
	String issueBook(BookIssue bookIssue);
	 String returnBook(BookIssue bookIssue);
	 BookIssue getBookIssuedById(Integer issueId);
	 List<BookIssue> getIssuedBook(); 
//	 void inputConfirmIssueBook();
	 List<BookIssue> displayUnissuedBook();
	 BookIssue findRecordByIssueId(Integer issueId);
	String confirmIssueBook(BookIssue bookIssue);
	
	 
}