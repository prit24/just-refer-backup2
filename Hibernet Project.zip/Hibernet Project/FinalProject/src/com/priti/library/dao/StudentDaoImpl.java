package com.priti.library.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.priti.library.entity.Student;

public class StudentDaoImpl implements StudentDao
{
	EntityManager entityManager=MyConnection.getEntityManagerObject();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	@Override
	public String addStudent(Student student) {
		entityTransaction.begin();
		entityManager.persist(student);
		entityTransaction.commit();
		return "Student Registration done\n studentId :"+student.getStudId();
	}
		
	
	@Override
	public Student getStudentById(Integer studentId) {
		
		return entityManager.find(Student.class, studentId);
	}
	
	@Override
	public Integer updateStudentTotalFine(Student student1,Double studentTotalFine1) {
		entityTransaction.begin();
			Integer status = entityManager.createQuery("UPDATE Student s SET s.studentTotalFine=?1 WHERE s.studentId=?2").setParameter(1, studentTotalFine1).setParameter(2, student1.getStudId()).executeUpdate();
		entityTransaction.commit();
		
		return status;
	}

}