package com.priti.library.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.priti.library.entity.BookIssue;

public class BookIssueDaoImpl implements BookIssueDao
{
	EntityManager entityManager=MyConnection.getEntityManagerObject();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	Query query;
	@Override
	public String issueBook(BookIssue bookIssue) {
		entityTransaction.begin();
		entityManager.persist(bookIssue);
		entityTransaction.commit();
		return "Book issue request sended to the Admin";
	}
			
	@Override
	public String returnBook(BookIssue bookIssue) {
		BookIssue bookIssue1= entityManager.find(BookIssue.class, bookIssue.getIssueId());
		if(bookIssue1!=null) {
			entityTransaction.begin();
			bookIssue1.setReturnDate(bookIssue.getReturnDate());
			bookIssue1.setBookStatus(bookIssue.getBookStatus());
		}
		return "Book returned";
	}

	
	@Override
	public BookIssue getBookIssuedById(Integer issueId) {
		BookIssue bookIssue=entityManager.find(BookIssue.class, issueId);
		return bookIssue;
	}

	@Override
	public List<BookIssue> getIssuedBook() {
		String jpql="select b from BookIssue b";
		query=entityManager.createQuery(jpql);
		List<BookIssue> list=query.getResultList();
		return list;
	}

//	@Override
//	public void inputConfirmIssueBook() {
//		
//		
//	}

	@Override
	public List<BookIssue> displayUnissuedBook() {
		String jpql="SELECT  bi FROM BookIssue bi WHERE bi.bookStatus = 'NOT ISSUED'";
		query=entityManager.createQuery(jpql);
		List<BookIssue> list=query.getResultList();
		return list;
	}

	@Override
	public BookIssue findRecordByIssueId(Integer issueId) 
	{
		
		return entityManager.find(BookIssue.class, issueId);
	}

	@Override
	public String confirmIssueBook(BookIssue bookIssue) 
	{
		
		BookIssue bookIssue2= entityManager.find(BookIssue.class, bookIssue.getIssueId());
		
		entityTransaction.begin();
		bookIssue2.setBookStatus(bookIssue.getBookStatus());  
		entityTransaction.commit();
		entityManager.clear();
		return "Book is Confirmed";
	}
	
	
}