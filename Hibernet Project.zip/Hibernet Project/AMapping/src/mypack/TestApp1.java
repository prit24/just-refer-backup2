package mypack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp1
{

	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Employee employee=new Employee();	
		employee.setEmpName("rashi");
		employee.setEmail("rashi@gmail.com");
		Address address=new Address();
		
		address.setEmpNo(700);
		address.setEmpName("Navnand vila");
		address.setPincode(41315);
		
		employee.setAddress(address);
		entityTransaction.begin();
		entityManager.persist(employee);
		entityTransaction.commit();
		entityManager.close();
		entityManagerFactory.close();
		System.out.println("object saved");
		
	}

}
