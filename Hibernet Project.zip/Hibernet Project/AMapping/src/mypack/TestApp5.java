package mypack;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestApp5
{
     private static final Object pEmail = null;

	public static void main(String[] args) 
     {
    	Scanner scanner=new Scanner(System.in);
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		String jpql="update Person p set p.pName=:Name, p.pEmail=:Email where p.pNo=:No ";
		Query q=entityManager.createQuery(jpql);
		
		
		System.out.println("Enter The Number");
		Integer pNo=scanner.nextInt();
		
		System.out.println("Enter The Name");
		String pName=scanner.next();
		
		System.out.println("Enter The Salary");
		Float pSal=scanner.nextFloat();
		
		q.setParameter("No", pNo);
		q.setParameter("Name", pName);
		q.setParameter("Email", pEmail);
		
		entityTransaction.begin();
		int count=q.executeUpdate();
		entityTransaction.commit();
		
			System.out.println("Object updated sucessfully");		
			}
	 } 
