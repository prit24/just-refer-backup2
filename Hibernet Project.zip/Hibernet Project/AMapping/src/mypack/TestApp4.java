package mypack;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestApp4
{
     public static void main(String[] args) 
     {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
        Scanner scanner=new Scanner(System.in);
		System.out.println("Enter The Name");
		String empName=scanner.next();
		
		String jpql="from Employee e";
		Query q=entityManager.createQuery(jpql);
		List<Employee>l=q.getResultList();
		Iterator<Employee> itr=l.iterator();
		while(itr.hasNext())
		{
			Employee employee=itr.next();
			
			System.out.println(employee.getAddress().getEmpNo());
			System.out.println(employee.getAddress().getEmpName());
			System.out.println(employee.getAddress().getPincode());
			entityManager.close();
			entityManagerFactory.close();
		}		
	 } 
}
