package mypack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestApp3
{

	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		Integer empNo=1;
		Employee employee=entityManager.find(Employee.class, empNo);
		
		if(employee!=null) 
		{
			EntityTransaction entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			
			entityManager.remove(employee);
			entityTransaction.commit();
			System.out.println("Employee removed");
				
		}
		else
		{
			System.out.println("Employee not found");
		}
		entityManager.close();
		entityManagerFactory.close();

}
}