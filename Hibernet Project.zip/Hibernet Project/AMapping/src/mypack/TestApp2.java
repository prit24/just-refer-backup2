package mypack;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestApp2 
{

	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("pri");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		Integer empNo=2;
		Employee employee=entityManager.find(Employee.class, empNo);
		
		Address address=employee.getAddress();
		
		System.out.println("House No is :"+address.getEmpNo());
		System.out.println("House Name is :"+address.getEmpName());
		System.out.println("pincode is :"+address.getPincode());
		entityManager.close();
		entityManagerFactory.close();
	}

}
