package mypack;


import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Address 
{
      @Id
      private Integer empNo;
      private String empName;
      private Integer pincode;

      public Integer getEmpNo() {
		return empNo;
	}
	public void setEmpNo(Integer empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Integer getPincode() {
		return pincode;
	}
	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}
      
  
      
}
