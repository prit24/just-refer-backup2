package com.library.basic.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer bookId;

    @Column(length = 100)
    private String bookName;

    @Column(length = 100)
    private String authorName;

    @Column(length = 50)
    private String bookPublisher;

    private Integer quantity=0;

    @Column(length = 50)
    private String bookType;

    @Column(length = 12)
    private String bookArrived = "NOT ARRIVED";

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "book")
    private List<BookIssue> bookIssue;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "requestedStudentId")  // Updated name of the column
    private Student requestedStudent;

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public String getBookPublisher() {
		return bookPublisher;
	}

	public void setBookPublisher(String bookPublisher) {
		this.bookPublisher = bookPublisher;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getBookType() {
		return bookType;
	}

	public void setBookType(String bookType) {
		this.bookType = bookType;
	}

	public String getBookArrived() {
		return bookArrived;
	}

	public void setBookArrived(String bookArrived) {
		this.bookArrived = bookArrived;
	}

	public List<BookIssue> getBookIssue() {
		return bookIssue;
	}

	public void setBookIssue(List<BookIssue> bookIssue) {
		this.bookIssue = bookIssue;
	}

	public Student getRequestedStudent() {
		return requestedStudent;
	}

	public void setRequestedStudent(Student requestedStudent) {
		this.requestedStudent = requestedStudent;
	}

//    // Additional @ManyToOne association with Student
//    @ManyToOne(cascade = CascadeType.ALL)
//    @JoinColumn(name = "studentId")
//    private Student student;

    // not required to create setter and getter as we include @Setter @Getter (using lombok dependency)
}
