package com.library.basic.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Admin {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer adminId;
	@Column(length=80)
	private String adminName;
	@Column(length=50)
	private String adminEmail;
	@Column(length=14)
	private String adminContactNo;
	@Column(length=100)
	private String adminAddress;
	@Column(length=20)
	private String adminPassword;
	@Column(length=10)
	private String accoutStatus="DEACTIVE";
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy="bookIssueAdmin")
	private List<BookIssue> bookIssues ;

	public Integer getAdminId() {
		return adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public String getAdminContactNo() {
		return adminContactNo;
	}

	public void setAdminContactNo(String adminContactNo) {
		this.adminContactNo = adminContactNo;
	}

	public String getAdminAddress() {
		return adminAddress;
	}

	public void setAdminAddress(String adminAddress) {
		this.adminAddress = adminAddress;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	public String getAccoutStatus() {
		return accoutStatus;
	}

	public void setAccoutStatus(String accoutStatus) {
		this.accoutStatus = accoutStatus;
	}

	public List<BookIssue> getBookIssues() {
		return bookIssues;
	}

	public void setBookIssues(List<BookIssue> bookIssues) {
		this.bookIssues = bookIssues;
	}
	
	//not require to create setter and getter 
	// as we include @Setter @Getter (using lombok dependency)
	
}
