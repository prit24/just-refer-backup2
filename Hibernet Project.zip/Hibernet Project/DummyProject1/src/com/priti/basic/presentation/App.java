package com.priti.basic.presentation;
public interface App 
{
	void insertRecord();
	void modifyRecord();
	void removeRecord();
	void findRecord();
}
