package com.priti.basic.presentation;
import java.util.Scanner;
import com.priti.basic.entity.Employee;
import com.priti.basic.service.EmployeeService;
import com.priti.basic.service.EmployeeServiceImpl;
public class AppImpl implements App
{
	Scanner scanner = new Scanner(System.in);
	EmployeeService employeeService = new EmployeeServiceImpl();
    @Override
	public void insertRecord() 
	{
		System.out.println("Enter the Employee Number : ");
		Integer empNo = scanner.nextInt();
		System.out.println("Enter the Employee Name : ");
		String empName = scanner.next();
		System.out.println("Enter the Employee Salary : ");
		Float empSal = scanner.nextFloat();
		Employee employee = new Employee();	
		employee.setEmpNo(empNo);
		employee.setEmpName(empName);
		employee.setEmpSal(empSal);
		String res = employeeService.insertRecord(employee);
		System.out.println(res);		
	}
	@Override
	public void modifyRecord()
	{
		System.out.println("Enter the Employee Number which you want to update : ");
		Integer empNo = scanner.nextInt();
		System.out.println("Enter the Employee Name : ");
		String empName = scanner.next();
		System.out.println("Enter the Employee Salary : ");
		Float empSal = scanner.nextFloat();
		Employee employee = new Employee();	
		employee.setEmpNo(empNo);
		employee.setEmpName(empName);
		employee.setEmpSal(empSal);
		String res = employeeService.ModifyRecord(employee);
		System.out.println(res);
	}
	@Override
	public void removeRecord() 
	{
		System.out.println("Enter the Employee Number which you want to delete from record : ");
		Integer empNo = scanner.nextInt();
		String res = employeeService.removeRecord(empNo);
		System.out.println(res);
	}
	@Override
	public void findRecord()
	{
		System.out.println("\nEnter the Employee Number :  ");
		Integer empNo = scanner.nextInt();
		System.out.println(employeeService.findRecord(empNo));
		Employee employee = new Employee();	
		if(employee != null)
		{
			System.out.println("Employee No  is:" + employee.getEmpNo());
			System.out.println("Employee Name is:" + employee.getEmpName());
			System.out.println("Employee Salary is:" + employee.getEmpSal());			
		}
		else
		{
			System.out.println("object not found.....");
		}
	}
}
