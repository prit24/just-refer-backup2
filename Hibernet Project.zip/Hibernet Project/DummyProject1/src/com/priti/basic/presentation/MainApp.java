package com.priti.basic.presentation;
import java.util.Scanner;
public class MainApp 
{
	public static void main(String[] args) 
	{
		App app = new AppImpl();
		while(true)
		{
			System.out.println("************* Menu **********");
			System.out.println("\t 1.Add Record" );
			System.out.println("\t 2.Modify Record");
			System.out.println("\t 3.Delete Record");
			System.out.println("\t 4.Search Record by Id");
			System.out.println("Enter your Choice : ");
			Scanner scanner = new Scanner(System.in);
			System.out.println();
			Integer ch = scanner.nextInt();
			switch(ch)
			{
				case 1 :
					app.insertRecord();
					break;
				case 2 :
					app.modifyRecord();
					break;
				case 3 :
					app.removeRecord();
					break;
				case 4 :
					app.findRecord();
					break;
				default :	
					System.out.println("You have enter wrong choice.....");
					System.exit(0);
			}
		}	
	}
}