package com.priti.basic.dao;
import com.priti.basic.entity.Employee;
public interface EmployeeDao 
{
	String insertRecord(Employee employee);
	String ModifyRecord(Employee employee);
	String removeRecord(Integer empNo);
	Employee findRecord(Integer empNo);

}