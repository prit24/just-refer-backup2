package com.priti.basic.dao;
import com.priti.basic.entity.Employee;
import javax.persistence.*;
public class EmployeeDaoImpl implements EmployeeDao 
{
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("raj");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();
	@Override
	public String insertRecord(Employee employee) 
	{
		entityTransaction.begin();
		entityManager.persist(employee);
		entityTransaction.commit();
		return "Add Record Successfully......";
	}
	@Override
	public String ModifyRecord(Employee employee)
	{
		Employee employee1 = entityManager.find(Employee.class, employee.getEmpNo());
		if(employee1 != null)
		{
			entityTransaction.begin();
			employee1.setEmpName(employee.getEmpName());
			employee1.setEmpSal(employee.getEmpSal());
			entityTransaction.commit();
			return "Modify record Successfully....";
		}
		else
		{
			return "Object Not Found.";
		}	
	}
	@Override
	public String removeRecord(Integer empNo) 
	{
		Employee employee = entityManager.find(Employee.class, empNo);
		if(employee != null)
		{
			entityTransaction.begin();
			entityManager.remove(employee);
			entityTransaction.commit();
			return "Modify record Successfully....";
		}
		else
		{
			return "Object Not Found.";
		}
	}
	@Override
	public Employee findRecord(Integer empNo)
	{
		Employee employee = entityManager.find(Employee.class, empNo);
		return employee;
	}
}