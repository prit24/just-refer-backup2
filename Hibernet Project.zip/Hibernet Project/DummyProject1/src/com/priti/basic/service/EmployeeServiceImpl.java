package com.priti.basic.service;

import com.priti.basic.dao.EmployeeDao;
import com.priti.basic.dao.EmployeeDaoImpl;
import com.priti.basic.entity.Employee;

public class EmployeeServiceImpl implements EmployeeService
{
	EmployeeDao employeeDao = new EmployeeDaoImpl();
	@Override
	public String insertRecord(Employee employee)
	{
		employeeDao.insertRecord(employee);
		return "Insert record Successfully....";
	}
	@Override
	public String ModifyRecord(Employee employee) 
	{
		employeeDao.ModifyRecord(employee);
		return "Update record Successfully....";
	}
	@Override
	public String removeRecord(Integer empNo) 
	{
		employeeDao.removeRecord(empNo);
		return "Delete record Successfully....";
	}
	@Override
	public Employee findRecord(Integer empNo) 
	{
		Employee employee = employeeDao.findRecord(empNo);
		return employee;
	}
}