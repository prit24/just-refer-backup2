package com.priti.basic.service;
import com.priti.basic.entity.Employee;
public interface EmployeeService 
{
	String insertRecord(Employee employee);
	String ModifyRecord(Employee employee);
	String removeRecord(Integer empNo);
	Employee findRecord(Integer empNo);

}